package com.sample.mq.stream.sink.messaging;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

/**
 * This class helps to send the mock payload to PAYLOAD MQ.
 * 
 * @author Nationwide.
 *
 */
@Component
public class MQQueueSender {

	private final static Logger LOGGER = LoggerFactory.getLogger(MQQueueSender.class);

	@Autowired
	JmsTemplate jmsTemplate;
	
	@Value("${MESSAGING.QUEUE}")
	String destinationQueue;

	public void sendMessage(final String text) throws Exception {
		LOGGER.debug("Message to be send to {} queue is {} ", destinationQueue , text);
		
		jmsTemplate.send(destinationQueue, new MessageCreator() {

			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(text);
			}
		});
	}

}