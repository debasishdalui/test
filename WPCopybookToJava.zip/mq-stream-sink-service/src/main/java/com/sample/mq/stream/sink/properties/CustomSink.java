package com.sample.mq.stream.sink.properties;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.stereotype.Component;

/**
 * This class customizes the org.springframework.messaging.SubscribableChannel.Sink
 * This will be used for Kafka communication
 */

@Component
public interface CustomSink {
	
	/** 
	 * This value is configured in the properties file under
	 * spring.cloud.stream.bindings.mqSinkInput.destination = {Actual Kafka Topic} 
	 */
	public static final String INPUT = "mqSinkInput";
	
	@Input(INPUT)
	SubscribableChannel mqSinkInput();

}
