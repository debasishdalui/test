package com.sample.mq.stream.sink.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sample.mq.stream.sink.messaging.MQQueueSender;
import com.sample.mq.stream.sink.properties.CustomSink;
 
@Component
public class MQSinkService {

	private final static Logger LOGGER = LoggerFactory.getLogger(MQSinkService.class);
	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
	
	@Autowired
	MQQueueSender mqQueueSender;
	
	@ServiceActivator(inputChannel = CustomSink.INPUT)
	public void sendMessageToMQQueue(String inputMessage) {
		try {
			LOGGER.debug("Message from Kafka is {} ", inputMessage);
			
			List<String> messageList = gson.fromJson(inputMessage, List.class);
			
			for (String msg : messageList) {
				LOGGER.debug("Sending Message {} ", msg);
				mqQueueSender.sendMessage(msg);
				LOGGER.debug("Message sent {}", msg);
			}
			
			LOGGER.debug("All Messages successfully send to MQ ");
		} catch (Exception e) {
			LOGGER.error("Exception in sending message to MQ : input : {}, message : {}", gson.toJson(inputMessage), e);
		}  
	}


}
