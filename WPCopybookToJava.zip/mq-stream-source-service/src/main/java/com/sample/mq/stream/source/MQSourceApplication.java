package com.sample.mq.stream.source;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

import com.sample.mq.stream.source.properties.CustomSource;

/**
 * The Class MQSourceApplication.
 */
@SpringBootApplication
@EnableBinding(CustomSource.class)
public class MQSourceApplication {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(MQSourceApplication.class, args);
	}
}
