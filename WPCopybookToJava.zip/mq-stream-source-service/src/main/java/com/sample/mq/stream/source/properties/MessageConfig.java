package com.sample.mq.stream.source.properties;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MessageConfig {

	@Value("${MESSAGING.QUEUE.MANAGER}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String queueManager;

	@Value("${MESSAGING.HOST}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String host;

	@Value("${MESSAGING.PORT}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String port;

	@Value("${MESSAGING.CHANNEL}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String channel;

	@Value("${MESSAGING.CLIENT.ID}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String clientId;

	@Value("${MESSAGING.CONNECTION.FACTORY.CONCURRENCY}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String connectionConcurrency;

	@Value("${MESSAGING.CONNECTION.FACTORY.RECOVERY.INTERVAL}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String recoveryInterval;

	@Value("${MESSAGING.CONNECTION.FACTORY.CACHE.LEVLE.NAME}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String cacheLevelName;

	@Value("${MESSAGING.CONNECTION.FACTORY.RECEIVE.TIME.OUT}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String receiveTimeout;

	@Value("${MESSAGING.CONNECTION.FACTORY.SESSION.ACKNOWLEDGEMENT.MODE}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String receivingAcknowledgementMode;

}
