package com.sample.mq.stream.source.properties;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

/**
 * This class customizes the org.springframework.messaging.MessageChannel.Source
 * This will be used for Kafka communication
 */
@Component
public interface CustomSource {
	
	/** 
	 * This value is configured in the properties file under
	 * spring.cloud.stream.bindings.mqSourceOutput.destination = {Actual Kafka Topic} 
	 */
	public static final String OUTPUT = "mqSourceOutput";
	

	@Output(OUTPUT)
	MessageChannel mqSourceOutput();

}
