package com.sample.mq.stream.source.configuration;

import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.Constants;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import com.ibm.mq.jms.MQXAConnectionFactory;
import com.sample.mq.stream.source.properties.MessageConfig;


/**
 * The Class MQStreamSourceConfiguration.
 */
@Configuration
@EnableJms
public class MQStreamSourceConfiguration {

	/** The Constant LOGGER. */
	private final static Logger LOGGER = LoggerFactory.getLogger(MQStreamSourceConfiguration.class);
	
	/** Constants instance for javax.jms.Session */
	private static final Constants sessionConstants = new Constants(Session.class);
	
	/**
	 * Dynamic destination resolver.
	 *
	 * @return the dynamic destination resolver
	 */
	@Bean
	DynamicDestinationResolver dynamicDestinationResolver(){
		return new DynamicDestinationResolver();
	}
	
	/**
	 * Mq XA connection factory.
	 *
	 * @param messageConfig the message config
	 * @return the MQXA connection factory
	 */
	@SuppressWarnings("deprecation")
	@Bean
	MQXAConnectionFactory mqXAConnectionFactory(@Qualifier("messageConfig") MessageConfig messageConfig){
		
		MQXAConnectionFactory returnConnectioFactory = null;
		try{
			returnConnectioFactory = new MQXAConnectionFactory();
			returnConnectioFactory.setTransportType(com.ibm.msg.client.wmq.WMQConstants.WMQ_CM_CLIENT);
			returnConnectioFactory.setQueueManager(messageConfig.getQueueManager());
			returnConnectioFactory.setHostName(messageConfig.getHost());
			returnConnectioFactory.setPort(Integer.parseInt(messageConfig.getPort()));
			returnConnectioFactory.setChannel(messageConfig.getChannel());
			returnConnectioFactory.setClientId(messageConfig.getClientId());
			
		}catch(Exception e){
			LOGGER.error("Exception while setting the MQXAConnectionFactory {} " , e);
		}
		return returnConnectioFactory;	
	}
	
	/**
	 * Jms queue connection factory.
	 *
	 * @param mqXAConnectionFactory the mq XA connection factory
	 * @return the user credentials connection factory adapter
	 */
	@Bean
	@Primary
	UserCredentialsConnectionFactoryAdapter  jmsQueueConnectionFactory(@Qualifier("mqXAConnectionFactory") MQXAConnectionFactory mqXAConnectionFactory){
		UserCredentialsConnectionFactoryAdapter jmsQueueConnectionFactory = new UserCredentialsConnectionFactoryAdapter();
		jmsQueueConnectionFactory.setTargetConnectionFactory(mqXAConnectionFactory);
		return jmsQueueConnectionFactory;	
	}
	
	/**
	 * Default jms listener container factory.
	 *
	 * @param configurer the configurer
	 * @param jmsQueueConnectionFactory the jms queue connection factory
	 * @param messageConfig the message config
	 * @param dynamicDestinationResolver the dynamic destination resolver
	 * @return the default jms listener container factory
	 */
	@Bean	
    public DefaultJmsListenerContainerFactory defaultJmsListenerContainerFactory(
    		DefaultJmsListenerContainerFactoryConfigurer configurer,
    		@Qualifier("jmsQueueConnectionFactory") UserCredentialsConnectionFactoryAdapter jmsQueueConnectionFactory,
    		@Qualifier("messageConfig") MessageConfig messageConfig,
    		@Qualifier("dynamicDestinationResolver") DynamicDestinationResolver dynamicDestinationResolver){
      DefaultJmsListenerContainerFactory defaultJmsListenerContainerFactory = new DefaultJmsListenerContainerFactory();
      configurer.configure(defaultJmsListenerContainerFactory, jmsQueueConnectionFactory);      
      defaultJmsListenerContainerFactory.setDestinationResolver(dynamicDestinationResolver);
      defaultJmsListenerContainerFactory.setConcurrency(messageConfig.getConnectionConcurrency());
      defaultJmsListenerContainerFactory.setRecoveryInterval(new Long(messageConfig.getRecoveryInterval()));
      defaultJmsListenerContainerFactory.setCacheLevelName(messageConfig.getCacheLevelName());
      defaultJmsListenerContainerFactory.setReceiveTimeout(new Long(messageConfig.getReceiveTimeout()));
      defaultJmsListenerContainerFactory.setSessionAcknowledgeMode(sessionConstants.asNumber(messageConfig.getReceivingAcknowledgementMode()).intValue());
      return defaultJmsListenerContainerFactory;
    }
}
