package com.sample.mq.stream.source.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sample.mq.stream.source.properties.CustomSource;

/**
 * The Class KafkaSender.
 */
@Service
public class KafkaSenderService {

	/** The Constant LOGGER. */
	private final static Logger LOGGER = LoggerFactory.getLogger(KafkaSenderService.class);

	/** The channel. */
	@Autowired
	private CustomSource channel;

	/** The gson. */
	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

	/**
	 * Stream message.
	 *
	 * @param messageToStream the message to stream
	 */
	public boolean streamMessage(String messageToStream) throws Exception {
		
		boolean streamStatus = false;
		
		MessageHeaderAccessor messageHeaderAccessor = new MessageHeaderAccessor();		
		messageHeaderAccessor.setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON);

		Message<String> message = MessageBuilder.createMessage(messageToStream, messageHeaderAccessor.getMessageHeaders());
		streamStatus = channel.mqSourceOutput().send(message);
			
		LOGGER.debug("Message Streaming completed: status: {}", streamStatus);
			
		return streamStatus;

	}
}
