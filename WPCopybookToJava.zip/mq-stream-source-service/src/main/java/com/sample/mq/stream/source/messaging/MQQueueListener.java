package com.sample.mq.stream.source.messaging;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sample.mq.stream.source.service.KafkaSenderService;

/**
 * The listener interface for receiving MQQueue events.
 * The class that is interested in processing a MQQueue
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addMQQueueListener<code> method. When
 * the MQQueue event occurs, that object's appropriate
 * method is invoked.
 *
 * @see MQQueueEvent
 */
@Component
public class MQQueueListener {
	
	/** The Constant LOGGER. */
	private final static Logger LOGGER = LoggerFactory.getLogger(MQQueueListener.class);
	
	/** The payload processor. */
	@Autowired
	KafkaSenderService kafkaSender;

	/** The gson. */
	Gson gson = new GsonBuilder().setPrettyPrinting().create();
	
	@Value("${MESSAGING.QUEUE}")
	String fromQueue;

	/**
	 * Process message.
	 *
	 * @param message the message
	 */
	@JmsListener(containerFactory = "${MESSAGING.CONNECTION.FACTORY.NAME}", destination = "${MESSAGING.QUEUE}")
	public void getMesssageFromQueueAndStream(Message message) {

		TextMessage msg = (TextMessage) message;
		
		try {

			LOGGER.debug("Message From {} Queue -> {} " , fromQueue, msg.getText());
			String payloadString = msg.getText();			
			boolean status = kafkaSender.streamMessage(payloadString);
			LOGGER.debug("Streaming status for message is {}" , status);

		} catch (Exception e) {
			LOGGER.error("Exception in getMesssageFromQueueAndStream method : input : {}, message : {}", gson.toJson(message), e);
		}

	}

}
