package com.gemfire.util.service;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import sample.gemfire.model.business.models.Person;
import sample.gemfire.model.business.models.PersonQueryResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.splunk.logging.SplunkCimLogEvent;

@Component
public class PersonService {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	@Autowired
	CacheFunctionInvokerService cacheFunctionInvokerService;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(PersonService.class);
	
	public List<Person> getPersons() {
		String query = "id != null";
		
		PersonQueryResult res = cacheFunctionInvokerService.findPersonWithQuery(query);
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("PERSON-QUERY-RESULT", res.getData());
		}}.toString());
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("PERSON-QUERY-RESULT-SIZE", res.getData().size());
		}}.toString());
		
		return res.getData();
		
	}

}
