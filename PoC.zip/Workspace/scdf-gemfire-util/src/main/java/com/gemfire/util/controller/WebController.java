package com.gemfire.util.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import sample.gemfire.model.business.models.Person;

import com.gemfire.util.service.PersonService;

@Controller
//@RequestMapping(value = "/test-status")
public class WebController extends WebMvcConfigurerAdapter {
	
	@Autowired
	PersonService personService;
	
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("results");
    }
    
    @GetMapping("/")
    public String showResults(Model model) {
    	List<Person> persons = personService.getPersons();
    	model.addAttribute("persons", persons);
    	model.addAttribute("size", persons.size());
        return "results";
    }

	
/*	@RequestMapping(method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.CREATED)
	@ResponseBody
	public String fetchPersons() {
		List<Person> result = personService.getPersons();
		return Integer.toString(result.size());
	}
*/}
