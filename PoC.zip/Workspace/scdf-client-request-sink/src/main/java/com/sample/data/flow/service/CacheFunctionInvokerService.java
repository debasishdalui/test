package com.sample.data.flow.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import sample.gemfire.model.business.models.Movies;
import sample.gemfire.model.business.models.MoviesPutResult;
import sample.gemfire.model.business.models.Person;
import sample.gemfire.model.business.models.PersonPutResult;
import sample.gemfire.model.function.CacheFunctionEnabledDataRegion;
import sample.gemfire.model.function.CacheSupportedFunctionOperation;
import sample.gemfire.model.function.FunctionResult;
import sample.gemfire.model.function.FunctionResultType;
import sample.gemfire.model.function.OperationInputKey;
import sample.gemfire.model.function.RegionOperationType;
import sample.gemfire.model.function.Status;

import com.gemstone.gemfire.cache.client.Pool;
import com.gemstone.gemfire.cache.execute.Execution;
import com.gemstone.gemfire.cache.execute.FunctionService;
import com.gemstone.gemfire.cache.execute.ResultCollector;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class CacheFunctionInvokerService {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(CacheFunctionInvokerService.class);
	
	private static final String PUT_EXECUTION_ERROR_MSG = "";
	private static final String PUT_EXECUTION_INPUT_DATA_ERROR_MSG = "";

	private static final String CACHE_FUNCTION_NAME = "CACHE_FUNCTION";

	private static final String UKNOWN_OPERATION_MSG = "";
	
	@Resource(name = "locatorPool")
	private Pool pool;
	
	public PersonPutResult putPerson(Person person) throws RuntimeException {
		PersonPutResult returnValue = new PersonPutResult();

		Map<String, Object> functionInput = new HashMap<String, Object>();
		functionInput.put(OperationInputKey.OPERATION_TYPE, RegionOperationType.SINGLE_REGION_OPERATION.getValue());
		functionInput.put(OperationInputKey.REGION_NAME,
				CacheFunctionEnabledDataRegion.PERSON_PARTITIONED_REGION.getValue());
		functionInput.put(OperationInputKey.OPERATION, CacheSupportedFunctionOperation.PUT.getValue());
		functionInput.put(OperationInputKey.KEY, person.getId());
		functionInput.put(OperationInputKey.VALUE, person);
		Execution functionExecution = FunctionService.onServer(pool).withArgs(functionInput);
		ResultCollector<?, ?> results = functionExecution.execute(CACHE_FUNCTION_NAME);

		// receive the generic function result
		List<?> list = (List<?>) results.getResult();
		FunctionResult functionResult = (FunctionResult) list.get(0);

		// extract the status from genetic result
		final String status = functionResult.getStatus();
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("PUTPERSON-STATUS", status);
		}}.toString());
		if ((status.equalsIgnoreCase(Status.SUCCESSFUL.getValue()))
				&& (functionResult.getResultType().equalsIgnoreCase(FunctionResultType.VOID.getValue()))) {
			returnValue.setStatus(Status.SUCCESSFUL.getValue());
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-PERSONPARTITIONEDREGION", "SUCCESSFULL");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.UNSUCCESSFUL.getValue())) {
			returnValue.setStatus(Status.UNSUCCESSFUL.getValue());
			returnValue.setMessage(PUT_EXECUTION_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-PERSONPARTITIONEDREGION", "UNSUCCESSFUL");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.INVALID_INPUT.getValue())) {
			returnValue.setMessage(Status.INVALID_INPUT.getValue());
			returnValue.setMessage(PUT_EXECUTION_INPUT_DATA_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-PERSONPARTITIONEDREGION", "INVALID_INPUT");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.UNKNOWN_OPERATION.getValue())) {
			returnValue.setStatus(Status.UNKNOWN_OPERATION.getValue());
			returnValue.setMessage(UKNOWN_OPERATION_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-PERSONPARTITIONEDREGION", "UNKNOWN_OPERATION");
			}}.toString());
		}

		return returnValue;
	}
	
	public MoviesPutResult putMovies(Movies movies) throws RuntimeException {
		MoviesPutResult returnValue = new MoviesPutResult();

		Map<String, Object> functionInput = new HashMap<String, Object>();
		functionInput.put(OperationInputKey.OPERATION_TYPE, RegionOperationType.SINGLE_REGION_OPERATION.getValue());
		functionInput.put(OperationInputKey.REGION_NAME,
				CacheFunctionEnabledDataRegion.MOVIES_PARTITIONED_REGION.getValue());
		functionInput.put(OperationInputKey.OPERATION, CacheSupportedFunctionOperation.PUT.getValue());
		functionInput.put(OperationInputKey.KEY, movies.getId());
		functionInput.put(OperationInputKey.VALUE, movies);
		Execution functionExecution = FunctionService.onServer(pool).withArgs(functionInput);
		ResultCollector<?, ?> results = functionExecution.execute(CACHE_FUNCTION_NAME);

		// receive the generic function result
		List<?> list = (List<?>) results.getResult();
		FunctionResult functionResult = (FunctionResult) list.get(0);

		// extract the status from genetic result
		final String status = functionResult.getStatus();
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("PUTMOVIES-STATUS", status);
		}}.toString());
		if ((status.equalsIgnoreCase(Status.SUCCESSFUL.getValue()))
				&& (functionResult.getResultType().equalsIgnoreCase(FunctionResultType.VOID.getValue()))) {
			returnValue.setStatus(Status.SUCCESSFUL.getValue());
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-MOVIESPARTITIONEDREGION", "SUCCESSFULL");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.UNSUCCESSFUL.getValue())) {
			returnValue.setStatus(Status.UNSUCCESSFUL.getValue());
			returnValue.setMessage(PUT_EXECUTION_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-MOVIESPARTITIONEDREGION", "UNSUCCESSFUL");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.INVALID_INPUT.getValue())) {
			returnValue.setMessage(Status.INVALID_INPUT.getValue());
			returnValue.setMessage(PUT_EXECUTION_INPUT_DATA_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-MOVIESPARTITIONEDREGION", "INVALID_INPUT");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.UNKNOWN_OPERATION.getValue())) {
			returnValue.setStatus(Status.UNKNOWN_OPERATION.getValue());
			returnValue.setMessage(UKNOWN_OPERATION_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("DATA-SAVE-STATUS-MOVIESPARTITIONEDREGION", "UNKNOWN_OPERATION");
			}}.toString());
		}

		return returnValue;
	}

}
