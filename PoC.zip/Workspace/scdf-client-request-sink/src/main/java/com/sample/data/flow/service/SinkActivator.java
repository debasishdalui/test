package com.sample.data.flow.service;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;

import sample.gemfire.model.business.models.Person;

import com.google.gson.Gson;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class SinkActivator {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	@Autowired
	CacheFunctionInvokerService cacheFunctionInvokerService;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(SinkActivator.class);
	
	private Gson gson = new Gson();
	
	@ServiceActivator(inputChannel = Sink.INPUT)
	public void serviceActivator(String msg) {
		final Person person = gson.fromJson(msg, Person.class);
		
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("Data-Flow-Sink-Input", person.toString());
		}}.toString());
		
		cacheFunctionInvokerService.putPerson(person);
	}

}
