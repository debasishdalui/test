package com.sample.data.flow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import sample.gemfire.model.business.models.Movies;
import sample.gemfire.model.business.models.MoviesPutResult;
import sample.gemfire.model.business.models.Person;
import sample.gemfire.model.business.models.PersonPutResult;

@RestController
@RequestMapping(value = "/test")
public class TestController {
	
	@Autowired
	CacheFunctionInvokerService cacheFunctionInvokerService;
	
	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	public String test() {
		
		Person p = new Person();
		p.setId(java.util.UUID.randomUUID().toString());
		p.setFirstName("AAA");
		p.setLastName("BBB");
		
		
		Movies m = new Movies();
		m.setId(java.util.UUID.randomUUID().toString());
		m.setName("Hero");
		m.setType("Action");
		
		PersonPutResult personPutResult = cacheFunctionInvokerService.putPerson(p);	
		
		MoviesPutResult moviesPutResult = cacheFunctionInvokerService.putMovies(m);
		
		String res1 = "Result of Person is " + personPutResult.getStatus();
		
		String res2 = " and Result of Movies is " + moviesPutResult.getStatus();
		
		return res1 +" "+ res2;
	}

}
