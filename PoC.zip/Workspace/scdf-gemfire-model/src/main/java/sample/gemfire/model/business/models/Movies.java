package sample.gemfire.model.business.models;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class Movies implements Serializable {
	private static final long serialVersionUID = 1L;

	@Getter
	@Setter (AccessLevel.PUBLIC) 
	private String id;
	
	@Getter
	@Setter (AccessLevel.PUBLIC) 
	@NotNull
	@Size(min=2, max=30)
	private String name;
	
	@Getter
	@Setter (AccessLevel.PUBLIC) 
	@NotNull
	@Size(min=2, max=30)
	private String type;

	@Override
	public String toString() {
		return "Movies [id=" + id + ", name=" + name + ", type=" + type + "]";
	}
	
	
	
}
