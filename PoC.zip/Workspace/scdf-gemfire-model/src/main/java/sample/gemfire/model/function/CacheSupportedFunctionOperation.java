package sample.gemfire.model.function;

	public enum CacheSupportedFunctionOperation{
		CONTAINSKEY("CONTAINSKEY"),
		CONTAINSVALUE("CONTAINSVALUE"),
		CONTAINSVALUEFORKEY("CONTAINSVALUEFORKEY"),
		CREATE("CREATE"),
		FIND("FIND"),
		FINDUNIQUE("FINDUNIQUE"),
		GET("GET"),
		GETALL("GETALL"),
		GET_FOR_UPDATE("GET_FOR_UPDATE"),
		UPDATE("UPDATE"),
		PUT("PUT"),
		PUTALL("PUTALL"),
		PUTIFABSENT("PUTIFABSENT"),
		QUERY("QUERY"),
		REMOVE("REMOVE"),
		REPLACE("REPLACE"),
		REPLACEWITHVERIFICATION("REPLACEWITHVERIFICATION"),
		CREATEREGION("CREATEREGION"),
		CLEAR("CLEAR");
		
		
		
		
		private CacheSupportedFunctionOperation(String value){
	        this.value = value;
	    }
	    private final String value;
	    
	    public String getValue(){return value;}
		
		
	}


