package sample.gemfire.model.function;

public enum RegionOperationType {
	
	SINGLE_REGION_OPERATION("SINGLE_REGION_OPERATION"),
	MULTI_REGION_OPERATION("MULTI_REGION_OPERATION");

    private RegionOperationType(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){return value;}

    

}
