package sample.gemfire.model.business.models;

import java.io.Serializable;
import java.util.List;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class MoviesQueryResult implements Serializable {
	
	 
	private static final long serialVersionUID = 1L;	
	@Getter @Setter (AccessLevel.PUBLIC)private String status;
	@Getter @Setter (AccessLevel.PUBLIC)private String message;
	@Getter @Setter (AccessLevel.PUBLIC)private List<Movies> data;
	
	

}
