package sample.gemfire.model.function;

import java.io.Serializable;
import java.util.List;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class FunctionResult implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	@Getter @Setter (AccessLevel.PUBLIC)
	private String status;
	
	@Getter @Setter (AccessLevel.PUBLIC)
	private boolean booleanResult;
	
	@Getter @Setter (AccessLevel.PUBLIC)
	private List<Object> listResult;
	
	@Getter @Setter (AccessLevel.PUBLIC)
	private String resultType;
	
	@Getter @Setter (AccessLevel.PUBLIC)
	private String time;
	
	@Getter @Setter (AccessLevel.PUBLIC)
	private boolean getForUpdate;
	
}
