package sample.gemfire.model.function;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public enum DateType {
	
	DATE_FORMAT_WITH_NANO_SECONDS("MM.dd.yyyy HH:mm:ss:SSSSSSS"),
	DATE_ONLY_FORMAT("YYYY-MM-DD"),
	DATE_FORMAT_EAGLE_EFFECTIVE_DATE ("MM-dd-yyyy HH-mm-ss");
	
    private DateType(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){
    	return value;
    }
    
    public String getDateAsString(){
    	DateFormat dateFormat = new SimpleDateFormat(value);
    	return dateFormat.format(new Date());    	
    }
    
   
    
    public String getDateAsString(Date date){
    	DateFormat dateFormat = new SimpleDateFormat(value);
    	return dateFormat.format(date);    	
    }
    
    public Date getStringAsDate(String date){
    	Date returnValue = null;
    	DateFormat dateFormat = new SimpleDateFormat(value);
    	try {
    		returnValue =  dateFormat.parse(date);
		} catch (ParseException e) {			
			e.printStackTrace();
		} 
    	return returnValue;
    }
    
    public String getDateStringFormated(String date){
    	String returnValue = null;
    	DateFormat dateFormat = new SimpleDateFormat(value);
    	try {
    		Date parsedDate =  dateFormat.parse(date);
    		returnValue = dateFormat.format(parsedDate);    		
		} catch (ParseException e) {			
			e.printStackTrace();
		} 
    	return returnValue;
    }
    
    public Date getAfterDateAsString(Date date1, Date date2){
    	Date returnValue = null;
    	DateFormat dateFormat = new SimpleDateFormat(value);
    	try {
    		String date1Formated = dateFormat.format(date1);
    		String date2Formated = dateFormat.format(date2);
    		Date date1Parsed =  dateFormat.parse(date1Formated);
    		Date date2Parsed =  dateFormat.parse(date2Formated);
    		if(date1Parsed.compareTo(date2Parsed) > 0){
    			returnValue = date1Parsed;
    		}else{
    			returnValue = date2Parsed;
    		}    		
    		
		} catch (ParseException e) {
			e.printStackTrace();
		} 
    	return returnValue;
    }
    
    public String getAfterDateAsString(String date1, String date2){
    	String returnValue = null;
    	DateFormat dateFormat = new SimpleDateFormat(value);
    	try {
    		Date date1Parsed = dateFormat.parse(date1);
    		Date date2Parsed = dateFormat.parse(date2);    		
    		if(date1Parsed.compareTo(date2Parsed) > 0){
    			returnValue = dateFormat.format(date1Parsed);
    		}else{
    			returnValue = dateFormat.format(date2Parsed);
    		}    		
    		
		} catch (ParseException e) {
			e.printStackTrace();
		} 
    	return returnValue;
    }


}


