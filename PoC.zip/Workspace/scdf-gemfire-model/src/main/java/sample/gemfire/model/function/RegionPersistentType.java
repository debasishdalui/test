package sample.gemfire.model.function;

public enum RegionPersistentType {
	
	EMPTY("EMPTY"),
	NORMAL("NORMAL"),	
	PRELOADED ("PRELOADED"),
	PARTITION ("PARTITION"),
	REPLICATION ("REPLICATION"),
	PERSISTENT_PARTITION ("PERSISTENT_PARTITION"),
	PERSISTENT_REPLICATE ("PERSISTENT_REPLICATE");
	
	
	

    private RegionPersistentType(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){return value;}

    

}
