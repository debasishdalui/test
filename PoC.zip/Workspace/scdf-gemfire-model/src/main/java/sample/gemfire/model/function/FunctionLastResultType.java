package sample.gemfire.model.function;

public enum FunctionLastResultType {
	
	COMMIT ("COMMIT"),
	ROLLBACK ("ROLLBACK");
    private FunctionLastResultType(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){return value;}

    

}
