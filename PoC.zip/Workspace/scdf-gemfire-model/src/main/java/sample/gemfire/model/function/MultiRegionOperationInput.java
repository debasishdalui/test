package sample.gemfire.model.function;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class MultiRegionOperationInput implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Getter @Setter (AccessLevel.PUBLIC)	
	@NotNull
	private List<SingleRegionOperationInput> regionInput;	 

}
