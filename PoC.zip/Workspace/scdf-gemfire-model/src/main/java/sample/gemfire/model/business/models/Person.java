package sample.gemfire.model.business.models;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class Person implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Getter
	@Setter(AccessLevel.PUBLIC)
	private String id;
	
	@Getter
	@Setter (AccessLevel.PUBLIC) 
	@NotNull
	@Size(min=2, max=30)
	private String firstName;
	
	@Getter
	@Setter (AccessLevel.PUBLIC) 
	@NotNull
	@Size(min=2, max=30)
	private String lastName;
	
	@Getter
	@Setter (AccessLevel.PUBLIC) 
	private String status;

	@Override
	public String toString() {
		return "Person [id=" + id + ", firstName=" + firstName + ", lastName="
				+ lastName + ", status=" + status + "]";
	}
	
	

}
