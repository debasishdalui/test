package sample.gemfire.model.function;

import java.io.Serializable;
import java.util.Map;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class SingleRegionOperationInput implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Getter @Setter (AccessLevel.PUBLIC)	
	@NotNull
	private String region;
	
	@Getter @Setter (AccessLevel.PUBLIC)	
	@NotNull
	private String operation;
	
	@Getter @Setter (AccessLevel.PUBLIC)		 
	private String key;
	
	@Getter @Setter (AccessLevel.PUBLIC)		 
	private Object value;
	
	@Getter @Setter (AccessLevel.PUBLIC)		 
	private String query;
	
	@Getter @Setter (AccessLevel.PUBLIC)		 
	private Object[] queryParam;
	
	@Getter @Setter (AccessLevel.PUBLIC)		 
	private Map<String,Object> valueMap;
	
	@Getter @Setter (AccessLevel.PUBLIC)	
	private Map<String, Object> regionAttributes;
	
	 

}
