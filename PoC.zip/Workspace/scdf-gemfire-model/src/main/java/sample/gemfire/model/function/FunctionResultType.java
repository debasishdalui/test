package sample.gemfire.model.function;

public enum FunctionResultType {
	
	BOOLEAN ("BOOLEAN"),
	OBJECTS ("OBJECTS"),	
	VOID ("VOID");
    private FunctionResultType(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){return value;}

    

}
