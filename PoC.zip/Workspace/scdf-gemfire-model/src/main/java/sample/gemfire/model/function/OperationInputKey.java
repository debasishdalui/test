package sample.gemfire.model.function;

import java.io.*;

public class OperationInputKey implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String REGION_NAME = "REGION_NAME";
	public static final String KEY = "KEY";
	public static final String OPERATION = "OPERATION";
	public static final String CONTAINS_VALUE = "CONTAINS_VALUE";
	public static final String QUERY = "QUERY";
	public static final String QUERY_PARAM = "QUERY_PARAM";
	public static final String VALUE = "VALUE";
	public static final String VALUE_MAP = "VALUE_MAP";
	public static final String REGION_ATTRIBUTES = "REGION_ATTRIBUTES";
	public static final String MULTI_REGION_OPERATION_INPUT = "MULTI_REGION_OPERATION_INPUT";	
	//public static final String SINGLE_REGION_OPERATION = "SINGLE_REGION_OPERATION";
	
	public static final String OPERATION_TYPE = "OPERATION_TYPE";
	

}
