package sample.gemfire.model.function;

 
public enum Status {
	SUCCESSFUL("SUCCESSFUL"), 
	UNSUCCESSFUL("UNSUCCESSFUL"),
	ALREADY_EXISTS("ALREADY_EXISTS"), 
	INVALID_INPUT("INVALID_INPUT"),
	NO_RESULT("NO_RESULT"),
	UNKNOWN_OPERATION("UNKNOWN_OPERATION");
	
	private Status(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){return value;}
};