package sample.gemfire.model.business.models;

import java.io.Serializable;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class MoviesFindResult implements Serializable {
	
	private static final long serialVersionUID = 1L;	
	@Getter @Setter (AccessLevel.PUBLIC)private String status;
	@Getter @Setter (AccessLevel.PUBLIC)private String message;
	@Getter @Setter (AccessLevel.PUBLIC)private Movies data;
}
