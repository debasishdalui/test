package sample.gemfire.model.function;

public enum RegionScope {
	
	DISTRIBUTED_ACK ("DISTRIBUTED_ACK "),
	DISTRIBUTED_NO_ACK ("DISTRIBUTED_NO_ACK"),	
	GLOBAL ("GLOBAL"),
	LOCAL("LOCAL ");
	
    private RegionScope(String value){
        this.value = value;
    }
    private final String value;
    
    public String getValue(){return value;}

    

}
