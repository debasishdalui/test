package sample.gemfire.model.function;

public enum CacheFunctionEnabledDataRegion {

			MOVIES_PARTITIONED_REGION("MOVIES_PARTITIONED_REGION"), 
			PERSON_PARTITIONED_REGION("PERSON_PARTITIONED_REGION");

	private static final String MOVIES_PARTITIONED_REGION_NAME = "moviesPartitionedRegion";
	private static final String PERSON_PARTITIONED_REGION_NAME = "personPartitionedRegion";

	private CacheFunctionEnabledDataRegion(String value) {
		this.value = value;
	}

	private final String value;

	public String getValue() {
		return value;
	}

	public String getOriginalRegionName() {

		String returnValue = null;

		switch (value) {

		case "MOVIES_PARTITIONED_REGION":
			returnValue = MOVIES_PARTITIONED_REGION_NAME;
			break;

		case "PERSON_PARTITIONED_REGION":
			returnValue = PERSON_PARTITIONED_REGION_NAME;
			break;

		}

		return returnValue;

	}

}
