package com.sample.gemfire.cache.service.properties;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;


public class CacheCustomConfig {
	
	@Value("${CACHE.CLOSE.INDICATOR}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheCloseIndicator;
	
	@Value("${CACHE.COPY.ON.READ}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheCopyOnRead;
	
	@Value("${CACHE.CRITICAL.HEAP.PERCENTAGE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheCriticalHeapPercentage;
	
	@Value("${CACHE.EVICTION.HEAP.PERCENTAGE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheEvictionHeapPercentage;
	
	@Value("${CACHE.ENABLE.AUTO.CORRECT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheEnableAutoCorrect;
	
	@Value("${CACHE.LOCK.LEASE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheLockLease;
	
	@Value("${CACHE.LOCK.TIMEOUT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheLockTimeout;
	
	@Value("${CACHE.MESSAGE.SYNC.INTERVAL}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheMessageSyncInterval;
	
	@Value("${CACHE.PDX.PERSISTENT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cachePdxPersistent;
	
	@Value("${CACHE.PDX.READ.SERIALIZED}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cachePdxReadSerialized;
	
	@Value("${CACHE.PDX.IGNORE.UNREAD.FIELDS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cachePdxIgnoreUnreadFields;
	
	@Value("${CACHE.SEARCH.TIMEOUT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheSearchTimeOut;
	
	@Value("${CACHE.USE.CLUSTER.CONFIGURATION}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheUseClusterConfiguration;
	
	@Value("${CACHE.LAZY.INIT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String cacheLazyInit;
	
	
	
}
