package com.sample.gemfire.cache.service.repository;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

public class CacheFuctionExcectionException extends RuntimeException {


	private static final long serialVersionUID = 1L;
	
	@Getter @Setter (AccessLevel.PUBLIC)private String region;
	@Getter @Setter (AccessLevel.PUBLIC)private String description;
	
	public CacheFuctionExcectionException(String region, String description){
		
		this.region = region;
		this.description = description;
		
	}
	

}
