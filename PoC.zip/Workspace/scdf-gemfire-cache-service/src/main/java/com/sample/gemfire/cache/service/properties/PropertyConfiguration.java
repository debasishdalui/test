package com.sample.gemfire.cache.service.properties;

import java.util.Properties;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;

public class PropertyConfiguration {

	private static final String CACHE_CUSTOM_CONFIG_YML = "CacheCustomConfig.yml";
	private static final String CACHE_SERVER_CONFIG_YML = "CacheServerConfig.yml";
	private static final String CACHE_REGION_CONFIG_YML = "CacheRegionConfig.yml";
	private static final String CACHE_ASYNC_EVENT_QUEUE_CONFIG_YML = "CacheAsyncEventQueueConfig.yml";
	private static final String CACHE_STORAGE_CONFIG_YML = "CacheStorageConfig.yml";
	private static final String CACHE_QUERY_CONFIG_YML = "CacheQueryConfig.yml";
	private static final String CACHE_LOCATOR_CONFIG_YML = "CacheLocatorConfig.yml";
	
	private String propertyDefaultProfilePath = "/annotation/yaml/";
	private String propertyProfilePath = "/annotation/yaml/";

	public PropertyConfiguration(String propertyProfilePath) {
		this.propertyProfilePath = propertyProfilePath;
	}

	@Bean
	public PropertySourcesPlaceholderConfigurer cachePropertySourcesPlaceholder() {
		PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
		YamlPropertiesFactoryBean cacheCustomConfigYML = new YamlPropertiesFactoryBean();
		YamlPropertiesFactoryBean cacheServerConfigYML = new YamlPropertiesFactoryBean();
		YamlPropertiesFactoryBean cacheRegionConfigYML = new YamlPropertiesFactoryBean();
		YamlPropertiesFactoryBean cacheQueryConfigYML = new YamlPropertiesFactoryBean();
		YamlPropertiesFactoryBean cacheLocatorConfigYML = new YamlPropertiesFactoryBean();

		YamlPropertiesFactoryBean cacheAsyncEventQueueConfigYML = new YamlPropertiesFactoryBean();
		YamlPropertiesFactoryBean cacheRegionStorageConfigYML = new YamlPropertiesFactoryBean();
		cacheCustomConfigYML.setResources(new ClassPathResource(buildYamlDefaultPropertyPath(CACHE_CUSTOM_CONFIG_YML)));
		cacheAsyncEventQueueConfigYML.setResources(new ClassPathResource(buildYamlDefaultPropertyPath(CACHE_ASYNC_EVENT_QUEUE_CONFIG_YML)));
		cacheRegionStorageConfigYML.setResources(new ClassPathResource(buildYamlDefaultPropertyPath(CACHE_STORAGE_CONFIG_YML)));
		cacheQueryConfigYML.setResources(new ClassPathResource(buildYamlDefaultPropertyPath(CACHE_QUERY_CONFIG_YML)));
		cacheRegionConfigYML.setResources(new ClassPathResource(buildYamlDefaultPropertyPath(CACHE_REGION_CONFIG_YML)));

		// environment specific configurations
		cacheLocatorConfigYML.setResources(new ClassPathResource(buildYamlProfilePropertyPath(CACHE_LOCATOR_CONFIG_YML)));
		cacheServerConfigYML.setResources(new ClassPathResource(buildYamlProfilePropertyPath(CACHE_SERVER_CONFIG_YML)));

		Properties cacheCustomConfigProperties = cacheCustomConfigYML.getObject();
		Properties cacheStorageConfigProperties = cacheRegionStorageConfigYML.getObject();
		Properties cacheAsyncEventQueueConfigProperties = cacheAsyncEventQueueConfigYML.getObject();
		Properties cacheQueryConfigProperties = cacheQueryConfigYML.getObject();
		Properties cacheRegionConfigProperties = cacheRegionConfigYML.getObject();

		// environment specific configurations
		Properties cacheLocatorConfigProperties = cacheLocatorConfigYML.getObject();
		Properties cacheServerConfigProperties = cacheServerConfigYML.getObject();

		Properties mergedProperties = new Properties();
		mergedProperties.putAll(cacheCustomConfigProperties);
		mergedProperties.putAll(cacheStorageConfigProperties);
		mergedProperties.putAll(cacheAsyncEventQueueConfigProperties);
		mergedProperties.putAll(cacheQueryConfigProperties);

		// environment specific configurations
		mergedProperties.putAll(cacheLocatorConfigProperties);
		mergedProperties.putAll(cacheServerConfigProperties);
		mergedProperties.putAll(cacheRegionConfigProperties);
		propertySourcesPlaceholderConfigurer.setProperties(mergedProperties);

		return propertySourcesPlaceholderConfigurer;
	}

	private String buildYamlDefaultPropertyPath(String yamlPropertyFile) {
		return this.propertyDefaultProfilePath + yamlPropertyFile;
	}

	private String buildYamlProfilePropertyPath(String yamlPropertyFile) {
		return this.propertyProfilePath + yamlPropertyFile;
	}

}
