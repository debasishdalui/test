package com.sample.gemfire.cache.service.repository;

import java.util.List;


import org.springframework.util.StringUtils;

import com.gemstone.gemfire.cache.asyncqueue.AsyncEvent;
import com.gemstone.gemfire.cache.asyncqueue.AsyncEventListener;
import com.gemstone.gemfire.cache.asyncqueue.AsyncEventQueue;


public class CacheAsyncEventListener implements AsyncEventListener {

	private AsyncEventQueue queue;

	private String name;

	public CacheAsyncEventListener() {
		this.queue = null;
	}

	public CacheAsyncEventListener(final AsyncEventQueue queue) {
		this.queue = queue;
	}

	public void init() {
		getQueue();
		System.out.printf("%1$s initialized!%n", this);
	}

	public AsyncEventQueue getQueue() {

		return queue;
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public void setQueue(final AsyncEventQueue queue) {
		this.queue = queue;
	}

	public boolean processEvents(final List<AsyncEvent> events) {
		return false;
	}

	public void close() {
	}

	public String toString() {
		return (StringUtils.hasText(getName()) ? getName() : getClass()
				.getName());
	}

}
