package com.sample.gemfire.cache.service.properties;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("dev")
public class DevPropertyConfiguration extends PropertyConfiguration {
	
	private static final String PROPERTY_PROFILE_PATH = "/annotation/yaml/dev/";

	public DevPropertyConfiguration() {
		super(PROPERTY_PROFILE_PATH);
	}


}
