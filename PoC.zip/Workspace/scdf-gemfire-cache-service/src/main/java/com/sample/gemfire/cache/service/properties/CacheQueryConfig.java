package com.sample.gemfire.cache.service.properties;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;



@Component
public class CacheQueryConfig {
	
	@Value("${gemfire.Query.VERBOSE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String queryDeugSettig;
	
	@Value("${gemfire.ALLOW_PERSISTENT_TRANSACTIONS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String persistedRegionTranEnabled;
	
	 
	
	
}
