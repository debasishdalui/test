package com.sample.gemfire.cache.service.repository;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sample.gemfire.cache.service.properties.CacheQueryConfig;

@Component
public class CacheQueryLogSetting {
	
	@Autowired
	CacheQueryConfig cacheQueryConfig;
	
	@PostConstruct
	   public void setProperty() {
		  System.setProperty("gemfire.Query.VERBOSE", cacheQueryConfig.getQueryDeugSettig());
		  System.setProperty("gemfire.ALLOW_PERSISTENT_TRANSACTIONS", cacheQueryConfig.getPersistedRegionTranEnabled());
	   }

}
