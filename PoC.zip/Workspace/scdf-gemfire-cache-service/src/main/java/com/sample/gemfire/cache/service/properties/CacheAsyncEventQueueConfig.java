package com.sample.gemfire.cache.service.properties;


import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;


public class CacheAsyncEventQueueConfig {
	
	@Value("${ASYNC.EVENT.QUEUE.BATCH.SIZE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String batchSize;
	
	@Value("${ASYNC.EVENT.QUEUE.PERSISTENT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String persistent;
	
	@Value("${ASYNC.EVENT.QUEUE.PARALLEL}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String parallel;
	
	@Value("${ASYNC.EVENT.QUEUE.MAX.QUEUE.MEMORY}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String maxQueueMemory;
	
	@Value("${ASYNC.EVENT.QUEUE.DISPATCHER.THREADS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String dispatcherThreads;
	
	
	
	
	
	
}
