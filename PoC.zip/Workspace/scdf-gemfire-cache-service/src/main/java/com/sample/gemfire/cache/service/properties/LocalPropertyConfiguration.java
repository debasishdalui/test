package com.sample.gemfire.cache.service.properties;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("local")
public class LocalPropertyConfiguration extends PropertyConfiguration {
	
	private static final String PROPERTY_PROFILE_PATH = "/annotation/yaml/local/";


	public LocalPropertyConfiguration() {
		super(PROPERTY_PROFILE_PATH);
	}


}
