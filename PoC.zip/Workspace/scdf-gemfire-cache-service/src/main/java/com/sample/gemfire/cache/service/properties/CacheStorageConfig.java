package com.sample.gemfire.cache.service.properties;

 
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;



public class CacheStorageConfig {
	
	@Value("${STORAGE.QUEUE.SIZE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String QueueSize;
	
	@Value("${STORAGE.AUTO.COMPACT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String autoCompact;
	
	@Value("${STORAGE.MAX.OPERATION.LOG.SIZE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String maxOperationLogSize;
	
	@Value("${STORAGE.TIME.INTERVAL}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String timeInterval;
	
	@Value("${STORAGE.DISK.PRIMARY.LOCATION}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String diskPrimaryLocation;
	
	@Value("${STORAGE.DISK.PRIMARY.LOCATION.SIZE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String diskPrimaryLocationSize;
	
	@Value("${STORAGE.DISK.SECONDARY.LOCATION}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String diskSecondaryLocation;
	
	@Value("${STORAGE.DISK.SECONDARY.LOCATION.SIZE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String diskSecondaryLocationSize;
	
	
	
	
}
