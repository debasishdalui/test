package com.sample.gemfire.cache.service.repository;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


public class CacheInitializer implements ApplicationContextAware {

	
	private final static Logger LOGGER = LoggerFactory.getLogger(CacheInitializer.class);
	private ApplicationContext context;
	
	
	

	@SuppressWarnings("unchecked")
	@PostConstruct
	public void init() {
		
	}
	
	@PreDestroy
	public void shutdown() {

	}

	@Override
	public void setApplicationContext(ApplicationContext ctx)
			throws BeansException {
		context = ctx;

	}

	
	
	

	
	
	
	
	
	
	

}
