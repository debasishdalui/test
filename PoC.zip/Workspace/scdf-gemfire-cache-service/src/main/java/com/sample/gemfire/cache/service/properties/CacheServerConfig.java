package com.sample.gemfire.cache.service.properties;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;



public class CacheServerConfig {
	
	@Value("${SERVER.AUTO.STARTUP}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String autoStartup;
	
	@Value("${SERVER.BIND.ADDRESS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String bindAddddress;
	
	@Value("${SERVER.HOST.FOR.CLIENTS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String hostForClients;
	
	@Value("${SERVER.LOCK.POLL.INTERVAL}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String pollInterval;
	
	@Value("${SERVER.MAX.CONNECTIONS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String maxConnections;
	
	@Value("${SERVER.MAX.THREADS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String maxThreads;
	
	@Value("${SERVER.MAX.MESSAGE.COUNT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String maxMessageCount;
	
	@Value("${SERVER.MAX.TIME.BETWEEN.PINGS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String maxTimeBetweenPings;
	
	@Value("${SERVER.GROUPS}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String groups;
	
	@Value("${SERVER.PORT.MIN.VALUE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String portRangeMinValue;
	
	@Value("${SERVER.PORT.MAX.VALUE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String portRangeMaxValue;
	
	
	
	
	
		
	
}
