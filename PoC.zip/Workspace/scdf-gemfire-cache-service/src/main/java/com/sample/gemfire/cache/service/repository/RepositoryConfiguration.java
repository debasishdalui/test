package com.sample.gemfire.cache.service.repository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.gemfire.CacheFactoryBean;
import org.springframework.data.gemfire.EvictionAttributesFactoryBean;
import org.springframework.data.gemfire.EvictionPolicyType;
import org.springframework.data.gemfire.ExpirationAttributesFactoryBean;
import org.springframework.data.gemfire.GemfireTemplate;
import org.springframework.data.gemfire.GemfireTransactionManager;
import org.springframework.data.gemfire.PartitionAttributesFactoryBean;
import org.springframework.data.gemfire.PartitionedRegionFactoryBean;
import org.springframework.data.gemfire.RegionAttributesFactoryBean;
import org.springframework.data.gemfire.server.CacheServerFactoryBean;
import org.springframework.data.gemfire.wan.AsyncEventQueueFactoryBean;

import sample.gemfire.model.business.models.Movies;
import sample.gemfire.model.business.models.Person;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheListener;
import com.gemstone.gemfire.cache.DataPolicy;
import com.gemstone.gemfire.cache.DiskStore;
import com.gemstone.gemfire.cache.DiskStoreFactory;
import com.gemstone.gemfire.cache.EvictionAction;
import com.gemstone.gemfire.cache.EvictionAttributes;
import com.gemstone.gemfire.cache.ExpirationAction;
import com.gemstone.gemfire.cache.ExpirationAttributes;
import com.gemstone.gemfire.cache.PartitionAttributes;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.pdx.ReflectionBasedAutoSerializer;
import com.sample.gemfire.cache.service.properties.CacheAsyncEventQueueConfig;
import com.sample.gemfire.cache.service.properties.CacheCustomConfig;
import com.sample.gemfire.cache.service.properties.CacheLocatorConfig;
import com.sample.gemfire.cache.service.properties.CacheRegionConfig;
import com.sample.gemfire.cache.service.properties.CacheServerConfig;
import com.sample.gemfire.cache.service.properties.CacheStorageConfig;
import com.sample.gemfire.cache.service.properties.DevPropertyConfiguration;
import com.sample.gemfire.cache.service.properties.LocalPropertyConfiguration;



@Configuration
@Import({ LocalPropertyConfiguration.class, DevPropertyConfiguration.class })
public class RepositoryConfiguration  {

	private static final String CACHE_ASYNC_EVENT_QUEUE_STORE_NAME = "cacheAsyncEventQueueStore";
	private static final String MOVIES_PARTITIONED_STORE_NAME = "moviesPartitionedStore";	
	private static final String PERSON_PARTITIONED_STORE_NAME = "personPartitionedStore";
	
	private static final String PDX_STORE_NAME = "pdxStore";
	
	
	
	
	private static final String MOVIES_PARTITIONED_REGION_NAME = "moviesPartitionedRegion";	
	private static final String PERSON_PARTITIONED_REGION_NAME = "personPartitionedRegion";
	private static final int  NON_PERSISTENT_REGION_ENTRY_TIMEOUT_DURATION = 120;
	

	@Bean
	CacheCustomConfig cacheCustomConfig() {
		CacheCustomConfig cacheCustomConfig = new CacheCustomConfig();
		return cacheCustomConfig;
	}
	
	@Bean
	CacheServerConfig cacheServerConfig() {
		CacheServerConfig cacheServerConfig = new CacheServerConfig();
		return cacheServerConfig;
	}
	
	@Bean
	CacheAsyncEventQueueConfig cacheAsyncEventQueueConfig() {
		CacheAsyncEventQueueConfig cacheAsyncEventQueueConfig = new CacheAsyncEventQueueConfig();
		return cacheAsyncEventQueueConfig;
	}
	
	@Bean
	CacheStorageConfig cacheStorageConfig() {
		CacheStorageConfig cacheStorageConfig = new CacheStorageConfig();
		return cacheStorageConfig;
	}

	@Bean
	CacheServerPortGenerator cacheServerPortGenerator() {
		CacheServerPortGenerator cacheServerPortGenerator = new CacheServerPortGenerator();
		return cacheServerPortGenerator;
	}

	@Bean
	CacheRegionConfig cacheRegionConfig() {
		CacheRegionConfig cacheRegionConfig = new CacheRegionConfig();
		return cacheRegionConfig;
	}
	
	@Bean
	CacheLocatorConfig cacheLocatorConfig() {
		CacheLocatorConfig cacheLocatorConfig = new CacheLocatorConfig();
		return cacheLocatorConfig;
	}
	
	

	@SuppressWarnings("deprecation")
	@Bean
	ReflectionBasedAutoSerializer pdxSerializer(@Qualifier("cacheRegionConfig") CacheRegionConfig cacheRegionConfig) {
		List<String> domainModelList = new ArrayList<String>();
		domainModelList.add(cacheRegionConfig.getDomainModelBasicPackageName());
		ReflectionBasedAutoSerializer reflectionBasedAutoSerializer = new ReflectionBasedAutoSerializer(
				domainModelList);
		
		return reflectionBasedAutoSerializer;
	}

	@Bean
	CacheFactoryBean dataCache(@Qualifier("cacheCustomConfig") CacheCustomConfig cacheCustomConfig,
			@Qualifier("pdxSerializer") ReflectionBasedAutoSerializer pdxSerializer) {
		
		CacheFactoryBean dataCache = new CacheFactoryBean();

		Properties locatorProperties = new Properties();
		locatorProperties.put("locators", getLocatorProperty());

		dataCache.setProperties(locatorProperties);
		dataCache.setClose(new Boolean(cacheCustomConfig.getCacheCloseIndicator()).booleanValue());
		dataCache.setCopyOnRead(new Boolean(cacheCustomConfig.getCacheCopyOnRead()));
		dataCache.setCriticalHeapPercentage(new Float(cacheCustomConfig.getCacheCriticalHeapPercentage()));
		dataCache.setEvictionHeapPercentage(new Float(cacheCustomConfig.getCacheEvictionHeapPercentage()));
		dataCache.setEnableAutoReconnect(new Boolean(cacheCustomConfig.getCacheEnableAutoCorrect()));
		dataCache.setLockLease(new Integer(cacheCustomConfig.getCacheLockLease()));
		dataCache.setLockTimeout(new Integer(cacheCustomConfig.getCacheLockTimeout()));
		dataCache.setMessageSyncInterval(new Integer(cacheCustomConfig.getCacheMessageSyncInterval()));
		dataCache.setPdxSerializer(pdxSerializer);
		dataCache.setPdxPersistent(new Boolean(cacheCustomConfig.getCachePdxPersistent()));
		dataCache.setPdxDiskStoreName(PDX_STORE_NAME);
		dataCache.setPdxReadSerialized(new Boolean(cacheCustomConfig.getCachePdxReadSerialized()));
		dataCache.setPdxIgnoreUnreadFields(new Boolean(cacheCustomConfig.getCachePdxIgnoreUnreadFields()));
		dataCache.setSearchTimeout(new Integer(cacheCustomConfig.getCacheSearchTimeOut()));
		dataCache.setUseClusterConfiguration(new Boolean(cacheCustomConfig.getCacheUseClusterConfiguration()));
		
		return dataCache;
	}

	@Bean
	CacheServerFactoryBean dataCacheServer(@Qualifier("dataCache") Cache dataCache,
			@Qualifier("cacheServerConfig") CacheServerConfig cacheServerConfig,
			@Qualifier("cacheServerPortGenerator") CacheServerPortGenerator cacheServerPortGenerator) {

		CacheServerFactoryBean dataCacheServer = new CacheServerFactoryBean();

		dataCacheServer.setAutoStartup(new Boolean(cacheServerConfig.getAutoStartup()).booleanValue());
		dataCacheServer.setBindAddress(cacheServerConfig.getBindAddddress());
		int portGenMinValue = new Integer(cacheServerConfig.getPortRangeMinValue()).intValue();
		int portGenMaxValue = new Integer(cacheServerConfig.getPortRangeMaxValue()).intValue();
		int dynamicPort = 0;
		try {
			dynamicPort = cacheServerPortGenerator.generatePort(portGenMinValue, portGenMaxValue);
		} catch (IOException e) {
			e.printStackTrace();
		}
		dataCacheServer.setPort(dynamicPort);
		dataCacheServer.setCache(dataCache);
		dataCacheServer.setHostNameForClients(cacheServerConfig.getHostForClients());
		dataCacheServer.setLoadPollInterval(new Long(cacheServerConfig.getPollInterval()).longValue());
		dataCacheServer.setMaxConnections(new Integer(cacheServerConfig.getMaxConnections()).intValue());
		dataCacheServer.setMaxThreads(new Integer(cacheServerConfig.getMaxThreads()).intValue());
		dataCacheServer.setMaxTimeBetweenPings(new Integer(cacheServerConfig.getMaxTimeBetweenPings()).intValue());
		String[] serverGrpList = new String [1];
		serverGrpList[0] = cacheServerConfig.getGroups();
		dataCacheServer.setServerGroups(serverGrpList);
		return dataCacheServer;
	}
	
	@Bean
	GemfireTransactionManager cacheTransactionManager(@Qualifier("dataCache") Cache dataCache){		
		GemfireTransactionManager cacheTransactionManager = new GemfireTransactionManager();
		cacheTransactionManager.setCache(dataCache);		
		return cacheTransactionManager;				
	}

	@Bean
	CacheAsyncEventListener cacheAsyncEventListener() {
		CacheAsyncEventListener cacheAsyncEventListener = new CacheAsyncEventListener();
		return cacheAsyncEventListener;
	}

	@Bean
	CacheSyncEventListener cacheSyncEventListener() {
		CacheSyncEventListener cacheSyncEventListener = new CacheSyncEventListener();
		return cacheSyncEventListener;
	}

	@Bean
	AsyncEventQueueFactoryBean cacheAsyncEventQueue(@Qualifier("dataCache") Cache dataCache,
			@Qualifier("cacheAsyncEventListener") CacheAsyncEventListener cacheAsyncEventListener, 
			@Qualifier("cacheAsyncEventQueueStore") DiskStore cacheAsyncEventQueueStore,
			@Qualifier("cacheAsyncEventQueueConfig") CacheAsyncEventQueueConfig cacheAsyncEventQueueConfig) {
			
		 
		AsyncEventQueueFactoryBean cacheAsyncEventQueue = new AsyncEventQueueFactoryBean(dataCache);
		cacheAsyncEventQueue.setBatchSize(new Integer(cacheAsyncEventQueueConfig.getBatchSize()).intValue());
		cacheAsyncEventQueue.setPersistent(new Boolean(cacheAsyncEventQueueConfig.getPersistent()).booleanValue());
		cacheAsyncEventQueue.setParallel(new Boolean(cacheAsyncEventQueueConfig.getParallel()).booleanValue());
		cacheAsyncEventQueue.setDiskStoreRef(cacheAsyncEventQueueStore.getName());
		cacheAsyncEventQueue.setMaximumQueueMemory(new Integer(cacheAsyncEventQueueConfig.getMaxQueueMemory()));
		cacheAsyncEventQueue.setAsyncEventListener(cacheAsyncEventListener); 
		return cacheAsyncEventQueue;
	}

	@Bean
	DiskStore cacheAsyncEventQueueStore(@Qualifier("dataCache") Cache dataCache,
			@Qualifier("cacheStorageConfig") CacheStorageConfig cacheStorageConfig) {
		
		DiskStore returnDiskStore = null;
		
		returnDiskStore = dataCache.findDiskStore(CACHE_ASYNC_EVENT_QUEUE_STORE_NAME);
		
		if (returnDiskStore == null) {			
			returnDiskStore = createDiskStore(CACHE_ASYNC_EVENT_QUEUE_STORE_NAME,  cacheStorageConfig, dataCache);
		}
		return returnDiskStore;
		
	}
	
	
	@Bean()
	DiskStore moviesPartitionedStore(@Qualifier("dataCache") Cache dataCache,
			@Qualifier("cacheStorageConfig") CacheStorageConfig cacheStorageConfig) {

		DiskStore returnDiskStore = null;
		returnDiskStore = dataCache.findDiskStore(MOVIES_PARTITIONED_STORE_NAME);
		if (returnDiskStore == null) {			
			returnDiskStore = createDiskStore(MOVIES_PARTITIONED_STORE_NAME,  cacheStorageConfig, dataCache);
		}
		return returnDiskStore;		
	}
	
	@Bean()
	DiskStore personPartitionedStore(@Qualifier("dataCache") Cache dataCache,
			@Qualifier("cacheStorageConfig") CacheStorageConfig cacheStorageConfig) {
		DiskStore returnDiskStore = null;
		returnDiskStore = dataCache.findDiskStore(PERSON_PARTITIONED_STORE_NAME);
		if (returnDiskStore == null) {			
			returnDiskStore = createDiskStore(PERSON_PARTITIONED_STORE_NAME,  cacheStorageConfig, dataCache);
		}
		return returnDiskStore;
		
	}
	
	@Bean()
	DiskStore pdxStore(@Qualifier("dataCache") Cache dataCache,
			@Qualifier("cacheStorageConfig") CacheStorageConfig cacheStorageConfig) {
		
		DiskStore returnDiskStore = null;
		returnDiskStore = dataCache.findDiskStore(PDX_STORE_NAME);
		if (returnDiskStore == null) {			
			returnDiskStore = createDiskStore(PDX_STORE_NAME,  cacheStorageConfig, dataCache);
		}
		return returnDiskStore;
		
	}
	
	@Bean()
	PartitionedRegionFactoryBean<String, Movies> moviesPartitionedRegion(@Qualifier("dataCache") Cache dataCache, @Qualifier("cacheStorageConfig") CacheStorageConfig cacheStorageConfig, @Qualifier("cacheRegionConfig") CacheRegionConfig cacheRegionConfig, @Qualifier("moviesPartitionedStore") DiskStore moviesPartitionedStore) {
		 
		
		PartitionedRegionFactoryBean<String, Movies> moviesPartitionedRegion = new PartitionedRegionFactoryBean<>();
		moviesPartitionedRegion.setCache(dataCache);
		moviesPartitionedRegion.setPersistent(new Boolean(cacheRegionConfig.getPersistence()));
		moviesPartitionedRegion.setName(MOVIES_PARTITIONED_REGION_NAME);
		moviesPartitionedRegion.setDiskStoreName(moviesPartitionedStore.getName());
		return moviesPartitionedRegion;
	}
	
	@Bean()
	PartitionedRegionFactoryBean<String, Person> personPartitionedRegion(@Qualifier("dataCache") Cache dataCache, @Qualifier("cacheRegionConfig") CacheRegionConfig cacheRegionConfig, @Qualifier("personPartitionedStore") DiskStore personPartitionedStore){
		PartitionedRegionFactoryBean<String, Person> personPartitionedRegion = new PartitionedRegionFactoryBean<>();
		personPartitionedRegion.setCache(dataCache);
		personPartitionedRegion.setPersistent(new Boolean(cacheRegionConfig.getPersistence()));
		personPartitionedRegion.setName(PERSON_PARTITIONED_REGION_NAME);		
		personPartitionedRegion.setDiskStoreName(personPartitionedStore.getName());
		return personPartitionedRegion;
	}
	
	@Bean 
	GemfireTemplate moviesPartitionedRegionTemplate(@Qualifier("moviesPartitionedRegion") Region moviesPartitionedRegion){
		GemfireTemplate moviesPartitionedRegionTemplate = new GemfireTemplate(moviesPartitionedRegion);		
		return moviesPartitionedRegionTemplate ;
	}
	
	@Bean 
	GemfireTemplate personPartitionedRegionTemplate(@Qualifier("personPartitionedRegion") Region personPartitionedRegion){
		GemfireTemplate personPartitionedRegionTemplate = new GemfireTemplate(personPartitionedRegion);		
		return personPartitionedRegionTemplate;
	}
	
	@SuppressWarnings("deprecation")
	@Bean
	  public RegionAttributesFactoryBean partitionedRegionAttributes(@SuppressWarnings("rawtypes") PartitionAttributes partitionAttributes,
	      EvictionAttributes evictionAttributes, ExpirationAttributes expirationAttributes, 
	      @Qualifier("synchronizedRegionEventListner") CacheListener<String, Object> synchronizedRegionEventListner) {

	    RegionAttributesFactoryBean partitionedRegionAttributes = new RegionAttributesFactoryBean();
	    partitionedRegionAttributes.setRegionTimeToLive(expirationAttributes);
	    partitionedRegionAttributes.setEvictionAttributes(evictionAttributes);
	    partitionedRegionAttributes.setPartitionAttributes(partitionAttributes);
	    partitionedRegionAttributes.setCacheListener(synchronizedRegionEventListner);
	    partitionedRegionAttributes.setDataPolicy(DataPolicy.PERSISTENT_PARTITION);
	    return partitionedRegionAttributes;
	  }
	
	@SuppressWarnings("deprecation")
	@Bean
	  public RegionAttributesFactoryBean replicatedRegionAttributes(@SuppressWarnings("rawtypes") PartitionAttributes partitionAttributes,
	      EvictionAttributes evictionAttributes, ExpirationAttributes expirationAttributes, 
	      @Qualifier("synchronizedRegionEventListner") CacheListener<String, Object> synchronizedRegionEventListner) {

	    RegionAttributesFactoryBean replicatedRegionAttributes = new RegionAttributesFactoryBean();
	    replicatedRegionAttributes.setRegionTimeToLive(expirationAttributes);
	    replicatedRegionAttributes.setEvictionAttributes(evictionAttributes);
	    replicatedRegionAttributes.setPartitionAttributes(partitionAttributes);
	    replicatedRegionAttributes.setCacheListener(synchronizedRegionEventListner);
	    replicatedRegionAttributes.setDataPolicy(DataPolicy.PERSISTENT_PARTITION);
	    return replicatedRegionAttributes;
	  }
	
	
	@SuppressWarnings("deprecation")
	@Bean
	public RegionAttributesFactoryBean nonPersistentRegionAttributes(
			@Qualifier("nonPersistentEvictionAttributes")EvictionAttributes nonPersistentEvictionAttributes, 
			@Qualifier("nonPersistentExpirationAttributes")ExpirationAttributes nonPersistentExpirationAttributes, 
			@Qualifier("synchronizedRegionEventListner") CacheListener<String, Object> synchronizedRegionEventListner) {

	    RegionAttributesFactoryBean nonPersistentRegionAttributes = new RegionAttributesFactoryBean();
	    nonPersistentRegionAttributes.setEntryTimeToLive(nonPersistentExpirationAttributes);
	    //nonPersistentRegionAttributes.setRegionTimeToLive(nonPersistentExpirationAttributes);
	    nonPersistentRegionAttributes.setEvictionAttributes(nonPersistentEvictionAttributes);
	    nonPersistentRegionAttributes.setCacheListener(synchronizedRegionEventListner);
	    nonPersistentRegionAttributes.setDataPolicy(DataPolicy.DEFAULT);
	    return nonPersistentRegionAttributes;
	  }
	   
	  @Bean
	  public PartitionAttributesFactoryBean partitionAttributes()
	  {
	    PartitionAttributesFactoryBean partitionAttributes = new PartitionAttributesFactoryBean();
	    return partitionAttributes;
	  }
	   
	 @Bean
	  public EvictionAttributesFactoryBean evictionAttributes()
	  {
	    //modify		 
		EvictionAttributesFactoryBean evictionAttributes = new EvictionAttributesFactoryBean();
	    evictionAttributes.setAction(EvictionAction.OVERFLOW_TO_DISK);	     
	    evictionAttributes.setType(EvictionPolicyType.MEMORY_SIZE);
	    return evictionAttributes;
	  }
	  
	 @Bean
	  public ExpirationAttributesFactoryBean expirationAttributes()
	  {
		//modify
		 ExpirationAttributesFactoryBean expirationAttributes = new ExpirationAttributesFactoryBean();
	    expirationAttributes.setAction(ExpirationAction.LOCAL_DESTROY);	    
	    return expirationAttributes;
	  }
	 
	 @Bean
	  public ExpirationAttributesFactoryBean nonPersistentExpirationAttributes()
	  {
		//modify
		ExpirationAttributesFactoryBean nonPersistentExpirationAttributes = new ExpirationAttributesFactoryBean();
		nonPersistentExpirationAttributes.setAction(ExpirationAction.DESTROY);	 
		nonPersistentExpirationAttributes.setTimeout(new Integer(NON_PERSISTENT_REGION_ENTRY_TIMEOUT_DURATION));
	    return nonPersistentExpirationAttributes;
	  }
	 
	 @Bean
	  public EvictionAttributesFactoryBean nonPersistentEvictionAttributes()
	  {
	    //modify		 
		EvictionAttributesFactoryBean nonPersistentEvictionAttributes = new EvictionAttributesFactoryBean();
		nonPersistentEvictionAttributes.setAction(EvictionAction.DEFAULT_EVICTION_ACTION);	     
		nonPersistentEvictionAttributes.setType(EvictionPolicyType.MEMORY_SIZE);
	    return nonPersistentEvictionAttributes;
	  }
	  
	 
	@Bean()
	CacheSyncEventListener synchronizedRegionEventListner(){
		CacheSyncEventListener cacheSyncEventListener = new CacheSyncEventListener();
		return cacheSyncEventListener;
	}
	
	@Bean ()
	CacheInitializer CacheInitializer(){
		CacheInitializer cacheInitializer = new CacheInitializer();
		return cacheInitializer;
	}
	
	
	private DiskStore createDiskStore(String name,  CacheStorageConfig cacheStorageConfig, Cache dataCache) {

		DiskStore returDiskStore = null;
		returDiskStore = dataCache.findDiskStore(name);
		if (returDiskStore == null) {
			DiskStoreFactory diskStoreFactory = dataCache.createDiskStoreFactory();
			diskStoreFactory.setAutoCompact(new Boolean(cacheStorageConfig.getAutoCompact()));
			//File array for primary and secondary file 
			File[] diskStoreFileArray = new File[2];
			diskStoreFileArray[0] = new File(cacheStorageConfig.getDiskPrimaryLocation() + "/" + name);
			diskStoreFileArray[1] = new File(cacheStorageConfig.getDiskSecondaryLocation()+ "/" + name);
			//File size array for primary and secondary
			int[] diskStoreSizeArray = new int[2];
			diskStoreSizeArray[0] = (new Integer(cacheStorageConfig.getDiskPrimaryLocationSize()));
			diskStoreSizeArray[1] = (new Integer(cacheStorageConfig.getDiskSecondaryLocationSize()));
			diskStoreFactory.setDiskDirsAndSizes(diskStoreFileArray, diskStoreSizeArray);
			//diskStoreFactory.setDiskUsageCriticalPercentage(cacheStorageConfig.);
			//diskStoreFactory.setDiskUsageWarningPercentage((new Long());
			diskStoreFactory.setMaxOplogSize(new Long(cacheStorageConfig.getMaxOperationLogSize()));
			diskStoreFactory.setQueueSize(new Integer(cacheStorageConfig.getQueueSize()));
			diskStoreFactory.setTimeInterval((new Long(cacheStorageConfig.getTimeInterval())));
			//diskStoreFactory.setWriteBufferSize(new Integer));
			returDiskStore = diskStoreFactory.create(name);
		}
		return returDiskStore;
	}
	
	private String getLocatorProperty() {
		String[] locatorSpecSplit = cacheLocatorConfig().getLocatorSpec().split("\\|");
		return locatorSpecSplit[0];
	}
}

