package com.sample.gemfire.cache.service.properties;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Value;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;



public class CacheLocatorConfig {
			
	@Value("${CACHE.LOCATOR.COUNT}")
	@Getter @Setter (AccessLevel.PUBLIC)
	@NotNull
	private String locatorCount;
	
	@Value("${CACHE.LOCATOR.SPEC}")
	@Getter @Setter (AccessLevel.PUBLIC)
	@NotNull
	private String locatorSpec;
	
	
	@Value("${CACHE.LOCATOR.HOST}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String locatorHost;
	
	@Value("${CACHE.LOCATOR.PORT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String locatorPort;
	
}
