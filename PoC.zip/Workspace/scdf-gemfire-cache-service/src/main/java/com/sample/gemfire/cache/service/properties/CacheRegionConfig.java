package com.sample.gemfire.cache.service.properties;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import org.springframework.beans.factory.annotation.Value;



public class CacheRegionConfig {
	
	@Value("${REGION.STORAGE.PERSISTENCE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String persistence;
	
	@Value("${REGION.STORAGE.NUMBER_OF_COPIES}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String copies;
	
	
	@Value("${REGION.DOMAIN.MODEL.PACKAGE}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
    String domainModelBasicPackageName;
	
	
	 
	
	
	
	
}
