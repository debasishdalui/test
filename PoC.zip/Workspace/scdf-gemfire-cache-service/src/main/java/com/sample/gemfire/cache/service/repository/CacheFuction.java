package com.sample.gemfire.cache.service.repository;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.gemfire.GemfireTemplate;
import org.springframework.data.gemfire.GemfireTransactionManager;
import org.springframework.stereotype.Component;

import sample.gemfire.model.business.models.Movies;
import sample.gemfire.model.business.models.Person;
import sample.gemfire.model.function.CacheFunctionEnabledDataRegion;
import sample.gemfire.model.function.CacheSupportedFunctionOperation;
import sample.gemfire.model.function.DateType;
import sample.gemfire.model.function.FunctionLastResultType;
import sample.gemfire.model.function.FunctionResult;
import sample.gemfire.model.function.FunctionResultType;
import sample.gemfire.model.function.OperationInputKey;
import sample.gemfire.model.function.RegionMetaData;
import sample.gemfire.model.function.RegionOperationType;
import sample.gemfire.model.function.RegionPersistentType;
import sample.gemfire.model.function.RegionScope;
import sample.gemfire.model.function.SingleRegionOperationInput;
import sample.gemfire.model.function.Status;

import com.gemstone.gemfire.cache.Cache;
import com.gemstone.gemfire.cache.CacheFactory;
import com.gemstone.gemfire.cache.DataPolicy;
import com.gemstone.gemfire.cache.DiskStore;
import com.gemstone.gemfire.cache.DiskStoreFactory;
import com.gemstone.gemfire.cache.EvictionAction;
import com.gemstone.gemfire.cache.EvictionAttributes;
import com.gemstone.gemfire.cache.ExpirationAction;
import com.gemstone.gemfire.cache.ExpirationAttributes;
import com.gemstone.gemfire.cache.Region;
import com.gemstone.gemfire.cache.RegionFactory;
import com.gemstone.gemfire.cache.Scope;
import com.gemstone.gemfire.cache.execute.FunctionAdapter;
import com.gemstone.gemfire.cache.execute.FunctionContext;
import com.gemstone.gemfire.cache.execute.ResultSender;
import com.gemstone.gemfire.cache.query.SelectResults;
import com.google.gson.Gson;

@SuppressWarnings("serial")
@Component
public class CacheFuction extends FunctionAdapter {

	private final static Logger LOGGER = LoggerFactory.getLogger(CacheFuction.class);
	
	private static String REGISTERED_NAME = "CACHE_FUNCTION";

	@Resource(name = "moviesPartitionedRegion")
	private Region<String, Object> moviesPartitionedRegion;

	@Resource(name = "moviesPartitionedRegionTemplate")
	private GemfireTemplate moviesPartitionedRegionTemplate;

	@Resource(name = "personPartitionedRegion")
	private Region<String, Person> personPartitionedRegion;

	@Resource(name = "personPartitionedRegionTemplate")
	private GemfireTemplate personPartitionedRegionTemplate;
	
	@Autowired
	GemfireTransactionManager cacheTransactionManager;

	private Cache cache;

	private Gson gson = new Gson();

	public CacheFuction() {
	}

	public String getId() {
		return REGISTERED_NAME;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(FunctionContext functionContext) {
		
		this.cache = CacheFactory.getAnyInstance();
		ResultSender<Object> resultSender = functionContext.getResultSender();
		try {
			Map<String, Object> input = (Map<String, Object>) functionContext.getArguments();
			String operationType = (String) input.get(OperationInputKey.OPERATION_TYPE);
			LOGGER.debug("Executig cache function execute method: input = {}, operatio type = {}", gson.toJson(input),
					operationType);
			if (operationType != null) {
				switch (RegionOperationType.valueOf(operationType.toUpperCase())) {
				case SINGLE_REGION_OPERATION:
					SingleRegionOperationInput singleRegionOperationInput = prepareSingleRegionInput(input);
					FunctionResult functionResult = doSingleRegionOperation(functionContext,
							singleRegionOperationInput);
					resultSender.sendResult(functionResult);
					break;
				case MULTI_REGION_OPERATION:					
					List<SingleRegionOperationInput> multiRegioOperationInput = (List<SingleRegionOperationInput>)input.get(OperationInputKey.MULTI_REGION_OPERATION_INPUT);
					if((multiRegioOperationInput != null) && (!multiRegioOperationInput.isEmpty())){
						for (SingleRegionOperationInput curInput: multiRegioOperationInput){
							FunctionResult curFunctionResult = doSingleRegionOperation(functionContext,
									curInput);
							resultSender.sendResult(curFunctionResult);							
						}
					}						
					break;
				default:
					break;
				}
			}			
		} catch (Exception e) {
			LOGGER.info("Exception in function execute method: message = {}", e.getMessage());
			e.printStackTrace();
		}finally{
			resultSender.lastResult(FunctionLastResultType.COMMIT.getValue());			
		}
	}

	private boolean executeContainsKeyOperation(String regionName, String key) throws CacheFuctionExcectionException {

		boolean returnValue = false;
		LOGGER.info("Executinng executeContainsKeyOperation with : region = {}, key = {}", regionName, key);

		try {
			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {
			
			case MOVIES_PARTITIONED_REGION:
				returnValue = moviesPartitionedRegionTemplate.containsKey(key);
				break;

			case PERSON_PARTITIONED_REGION:
				returnValue = personPartitionedRegionTemplate.containsKey(key);
				break;

			default:
				break;

			}
		} catch (Exception e) {
			LOGGER.info("Exception in executeContainsKeyOperation method: message = {}", e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	private boolean executeContainsValueOperation(String regionName, Object value)
			throws CacheFuctionExcectionException {

		boolean returnValue = false;

		LOGGER.info("Executing executeContainsValueOperation with: region = {}, value = {} ", regionName,
				gson.toJson(value));

		try {

			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:
				Movies moviesValue = (Movies) value;
				returnValue = moviesPartitionedRegionTemplate.containsValue(moviesValue);
				break;


			case PERSON_PARTITIONED_REGION:
				Person personValue = (Person) value;
				returnValue = personPartitionedRegionTemplate.containsValue(personValue);
				break;

			default:
				break;
			}
		} catch (Exception e) {
			LOGGER.info("exception in executeContainsValueOperation method: message = {}", e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	private boolean executeContainsValueForTheKey(String regionName, String key) throws CacheFuctionExcectionException {

		boolean returnValue = false;

		LOGGER.info("Executing executeContainsValueForTheKey with: region =  {}, key = {}" + regionName, key);

		try {

			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:
				returnValue = moviesPartitionedRegionTemplate.containsValueForKey(key);
				break;
				
			case PERSON_PARTITIONED_REGION:
				returnValue = personPartitionedRegionTemplate.containsValueForKey(key);
				break;

			default:
				break;

			}

		} catch (Exception e) {
			LOGGER.info("Exception in  executeContainsValueForTheKey method : message = {}" + e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	
	private void executeCreate(String regionName, String key, Object value) throws CacheFuctionExcectionException {

		LOGGER.info("Executing executeCreate with: region = {}, key = {}, value = {} " + regionName, key,
				gson.toJson(value));

		try {

			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:
				Movies moviesValue = (Movies) value;
				moviesPartitionedRegionTemplate.create(key, moviesValue);
				break;
			case PERSON_PARTITIONED_REGION:
				Person personValue = (Person) value;
				personPartitionedRegionTemplate.create(key, personValue);
				break;

			default:
				break;
			}

		} catch (Exception e) {
			LOGGER.info("Exception in executeCreate method : message = {}", e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

	}

	private SelectResults<Object> executeFind(String regionName, String query, Object[] queryParam)
			throws CacheFuctionExcectionException {

		SelectResults<Object> returnValue = null;

		LOGGER.info("Executing executeFind with: region = {}, query = {}, query param = {} ", regionName, query,
				gson.toJson(queryParam));

		try {
			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:
				returnValue = moviesPartitionedRegionTemplate.find(query, queryParam);
				break;
			case PERSON_PARTITIONED_REGION:
				returnValue = personPartitionedRegionTemplate.find(query, queryParam);
				break;

			default:
				break;

			}

		} catch (Exception e) {
			LOGGER.info("exception details : " + "\n" + e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	private Object executeFindUnique(String regionName, String query, Object[] queryParam)
			throws CacheFuctionExcectionException {

		Object returnValue = null;
		LOGGER.info("Executing executeFindUnique with: region =  {}, query = {}, query param = {}", regionName, query,
				gson.toJson(queryParam));
		try {

			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:
				returnValue = moviesPartitionedRegionTemplate.findUnique(query, queryParam);
				break;
			case PERSON_PARTITIONED_REGION:
				returnValue = personPartitionedRegionTemplate.findUnique(query, queryParam);
				break;

			default:
				break;

			}

		} catch (Exception e) {
			LOGGER.info("exception details : " + "\n" + e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	private Object executeGet(String regionName, String key) throws CacheFuctionExcectionException {

		Object returnValue = null;

		LOGGER.info("Executing executeGet with : region = {}, key = {} ", regionName, key);

		try {

			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:
				returnValue = moviesPartitionedRegionTemplate.get(key);
				break;
			case PERSON_PARTITIONED_REGION:
				returnValue = personPartitionedRegionTemplate.get(key);
				break;

			default:
				
				throw new RuntimeException("Requested region is not implemented: " + regionName.toUpperCase());

			}

		} catch (Exception e) {
			LOGGER.info("exception details : " + "\n" + e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	
	private SelectResults<Object>  executeGetAll(String regionName) throws CacheFuctionExcectionException {
	 
		 SelectResults<Object> returnValue = null;	 
		 LOGGER.info("executing executeGetAll with: " + "region = " + regionName);
		 String selectAllQuery = "key !=null";
		 returnValue =  executeQuery(regionName, selectAllQuery ) ;
		 return returnValue ; 	 
	  }
	 
	
	private void executePut(String regionName, String key, Object value) throws CacheFuctionExcectionException {

		LOGGER.info("Executing executePut with: region = {}, key = {}, value = {} ", regionName, key,
				gson.toJson(value));

		try {
			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {

			case MOVIES_PARTITIONED_REGION:

				Movies moviesValue = (Movies) value;
				moviesPartitionedRegionTemplate.put(key, moviesValue);
				break;
			case PERSON_PARTITIONED_REGION:
				Person personValue = (Person) value;
				personPartitionedRegionTemplate.put(key, personValue);
				break;

			default:
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("exception executePut : message = {}", e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

	}

	
	private void executePutAll(String regionName, Map<String, Object> valueMap)
			throws CacheFuctionExcectionException {

		LOGGER.info("executing executePutAll with: region =  {}, values = {}", regionName, gson.toJson(valueMap));

		try {
			//TBD

		} catch (Exception e) {
			LOGGER.info("Exception in executePutAll method : message = {} ", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException(regionName, e.getMessage());			
		}
	}

	
	private void executePutIfAbsent(String regionName, String key, Object value) {
		LOGGER.info("Executing executePutIfAbsent with: region = {}, value = {} ", regionName, gson.toJson(value));
		try {
			// taskEventPartitionedRegionTemplate.putIfAbsent(arg0, arg1)

		} catch (Exception e) {
			LOGGER.info("Exception in executePutIfAbsent method: message = {}", e.getMessage());
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}
	}

	private SelectResults<Object> executeQuery(String regionName, String query) throws CacheFuctionExcectionException {

		SelectResults<Object> returnValue = null;
		System.out.println("Executing executeQuery with: region = {}, query = {} " +  regionName + "  " + query);

		try {
			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {
			case MOVIES_PARTITIONED_REGION:
				returnValue = moviesPartitionedRegionTemplate.query(query);
				break;

			case PERSON_PARTITIONED_REGION:
				returnValue = personPartitionedRegionTemplate.query(query);
				break;

			default:
				break;
			}

		} catch (Exception e) {
			LOGGER.info("Exception in executeQuery method: message = {}", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	
	private void executeRemove(String regionName, String key) throws CacheFuctionExcectionException {

		LOGGER.info("Executing executeRemove with: region = {}, key = {}", regionName, key);

		try {

			switch (CacheFunctionEnabledDataRegion.valueOf(regionName.toUpperCase())) {
			case MOVIES_PARTITIONED_REGION:
				moviesPartitionedRegionTemplate.remove(key);
				break;

			case PERSON_PARTITIONED_REGION:
				personPartitionedRegionTemplate.remove(key);
				break;

			default:
				break;
			}

		} catch (Exception e) {
			LOGGER.info("Exception in executeRemove method: message = {}", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}
	}

	
	private void executeReplace(String regionName, String key, Object values) throws CacheFuctionExcectionException {

		LOGGER.info("Executing executeReplace with: region =  {}, key = {}", regionName, key);

		try {
			// taskEventPartitionedRegionTemplate.replace(arg0, arg1)

		} catch (Exception e) {
			LOGGER.info("Exception in executeReplace method : message = {}", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

	}

	
	private Object executeReplaceWithVerification(String regionName, String key, Object values)
			throws CacheFuctionExcectionException {

		Object returnValue = null;
		LOGGER.info("Executing executeReplaceWithVerification with: region = {}, key = {}, values = {} ", regionName,
				key, gson.toJson(values));

		try {

			// returnValue = taskEventPartitionedRegionTemplate.replace(key,
			// values);

		} catch (Exception e) {
			LOGGER.info("Exception in executeReplaceWithVerification method: message = {}", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

		return returnValue;

	}

	private Region<String, Object> createOrRetrieveRegion(Map<String, Object> regionValueMap)
			throws CacheFuctionExcectionException {

		LOGGER.info("Executing createOrRetrieveRegion with  regionValueMap = {}", gson.toJson(regionValueMap));

		Region<String, Object> region = null;
		try {
			region = this.cache.getRegion((String) regionValueMap.get(RegionMetaData.FULLY_QUALIFIED_NAME));

			if (region == null) {
				// create a new region
				RegionFactory<String, Object> regionFactory = this.cache.createRegionFactory();
				ExpirationAttributes regionIdleTimeToLive = new ExpirationAttributes(
						new Integer((String) regionValueMap.get(RegionMetaData.REGION_IDLE_TTL)).intValue(),
						ExpirationAction.INVALIDATE);
				ExpirationAttributes regionTimeToLive = new ExpirationAttributes(
						new Integer((String) regionValueMap.get(RegionMetaData.REGION_TTL)).intValue(),
						ExpirationAction.INVALIDATE);
				regionFactory.setRegionIdleTimeout(regionIdleTimeToLive);
				regionFactory.setRegionTimeToLive(regionTimeToLive);
				regionFactory.setCloningEnabled(
						(new Boolean(((String) regionValueMap.get(RegionMetaData.CLONE_ENABLED))).booleanValue()));
				regionFactory.setConcurrencyChecksEnabled(
						(new Boolean(((String) regionValueMap.get(RegionMetaData.CONCURRENCY_CHECKS_ENABLED)))
								.booleanValue()));
				regionFactory.setConcurrencyLevel(
						(new Integer(((String) regionValueMap.get(RegionMetaData.CONCURRENCY_LEVEL))).intValue()));

				switch (RegionPersistentType.valueOf((String) regionValueMap.get(RegionMetaData.DATA_POLICY))) {
				case NORMAL:
					regionFactory.setDataPolicy(DataPolicy.NORMAL);

				case EMPTY:
					regionFactory.setDataPolicy(DataPolicy.EMPTY);

				case PARTITION:
					regionFactory.setDataPolicy(DataPolicy.PARTITION);

				case REPLICATION:
					regionFactory.setDataPolicy(DataPolicy.PARTITION);

				case PERSISTENT_PARTITION:
					regionFactory.setDataPolicy(DataPolicy.PERSISTENT_PARTITION);

				case PERSISTENT_REPLICATE:
					regionFactory.setDataPolicy(DataPolicy.PERSISTENT_REPLICATE);

				case PRELOADED:
					regionFactory.setDataPolicy(DataPolicy.PRELOADED);

				default:
					regionFactory.setDataPolicy(DataPolicy.DEFAULT);

				}
				createDiskStore(regionValueMap);
				regionFactory.setDiskStoreName((String) regionValueMap.get(RegionMetaData.DISK_STORE_NAME));
				regionFactory.setDiskSynchronous(
						((Boolean) regionValueMap.get(RegionMetaData.DISK_SYNCHRONOUS)).booleanValue());
				regionFactory.setMulticastEnabled(
						((Boolean) regionValueMap.get(RegionMetaData.MULTICAST_ENABLED)).booleanValue());
				regionFactory.setEnableAsyncConflation(
						((Boolean) regionValueMap.get(RegionMetaData.MULTICAST_ENABLED)).booleanValue());
				regionFactory.setEnableSubscriptionConflation(
						((Boolean) regionValueMap.get(RegionMetaData.SUBCRIPTION_CONFLATION_ENABLED)).booleanValue());
				regionFactory.setEntryIdleTimeout(new ExpirationAttributes(
						((Integer) regionValueMap.get(RegionMetaData.ENTRY_IDLE_TIMEOUT)).intValue(),
						ExpirationAction.INVALIDATE));
				regionFactory.setEvictionAttributes(
						EvictionAttributes.createLRUEntryAttributes(EvictionAction.OVERFLOW_TO_DISK));
				regionFactory.setIndexMaintenanceSynchronous(
						((Boolean) regionValueMap.get(RegionMetaData.INDEX_MAINTENANCE_SYNCHRONOUS_ENABLED))
								.booleanValue());
				regionFactory.setInitialCapacity(
						new Integer((String) regionValueMap.get(RegionMetaData.INITIAL_CAPACITY)).intValue());
				switch (RegionScope.valueOf((String) regionValueMap.get(RegionMetaData.SCOPE))) {
				case DISTRIBUTED_ACK:
					regionFactory.setScope(Scope.DISTRIBUTED_ACK);

				case DISTRIBUTED_NO_ACK:
					regionFactory.setScope(Scope.DISTRIBUTED_ACK);

				case LOCAL:
					regionFactory.setScope(Scope.LOCAL);

				case GLOBAL:
					regionFactory.setScope(Scope.GLOBAL);

				default:
					regionFactory.setScope(Scope.DISTRIBUTED_ACK);
				}

				region = regionFactory.create((String) RegionMetaData.FULLY_QUALIFIED_NAME);

			}
		} catch (Exception e) {
			LOGGER.info("Exception in createOrRetrieveRegion method: message = {}", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException((String) regionValueMap.get(RegionMetaData.FULLY_QUALIFIED_NAME),
					e.getMessage());
		}

		return region;
	}

	
	private void clearRegion(String regionName) throws CacheFuctionExcectionException {

		LOGGER.info("Executing executeCreate with: region = {}", regionName);

		try {

			Region<String, Object> region = this.cache.getRegion(regionName);
			if (region != null) {
				region.clear();
			}

		} catch (Exception e) {
			LOGGER.info("Exception in clearRegion method: message = {} ", e.getMessage());
			e.printStackTrace();
			throw new CacheFuctionExcectionException(regionName, e.getMessage());
		}

	}

	private void createDiskStore(Map<String, Object> regionValueMap) {

		DiskStore returDiskStore = null;
		returDiskStore = this.cache.findDiskStore((String) regionValueMap.get(RegionMetaData.DISK_STORE_NAME));
		if (returDiskStore == null) {
			DiskStoreFactory diskStoreFactory = this.cache.createDiskStoreFactory();
			diskStoreFactory.setAutoCompact(
					((Boolean) regionValueMap.get(RegionMetaData.DISK_STORE_AUTO_COMPACT_ENALED)).booleanValue());
			File[] diskStoreFileArray = new File[2];
			diskStoreFileArray[0] = new File(
					(String) regionValueMap.get(RegionMetaData.DISK_STORE_PRIMARY_STORAGE_LOCATION));
			diskStoreFileArray[1] = new File(
					(String) regionValueMap.get(RegionMetaData.DISK_STORE_SECONDORY_STORAGE_LOCATION));
			int[] diskStoreSizeArray = new int[2];
			diskStoreSizeArray[0] = (new Integer(
					(String) regionValueMap.get(RegionMetaData.DISK_STORE_PRIMARY_STORAGE_SIZE))).intValue();
			diskStoreSizeArray[1] = (new Integer(
					(String) regionValueMap.get(RegionMetaData.DISK_STORE_SECONDORY_STORAGE_SIZE))).intValue();
			diskStoreFactory.setDiskDirsAndSizes(diskStoreFileArray, diskStoreSizeArray);
			diskStoreFactory.setDiskUsageCriticalPercentage(
					(new Long(((String) regionValueMap.get(RegionMetaData.DISK_STORE_USAGE_CRITICAL_PERCETAGE)))
							.longValue()));
			diskStoreFactory.setDiskUsageWarningPercentage(
					(new Long(((String) regionValueMap.get(RegionMetaData.DISK_STORE_USAGE_WARNING_PERCETAGE)))
							.longValue()));
			diskStoreFactory.setMaxOplogSize(
					(new Long(((String) regionValueMap.get(RegionMetaData.DISK_STORE_MAX_OPERATION_LOG_USE)))
							.longValue()));
			diskStoreFactory.setQueueSize(
					(new Integer((String) regionValueMap.get(RegionMetaData.DISK_STORE_QUEUE_SIZE)).intValue()));
			diskStoreFactory.setTimeInterval(
					(new Long(((String) regionValueMap.get(RegionMetaData.DISK_STORE_TIME_INTERVAL))).longValue()));
			diskStoreFactory.setWriteBufferSize(
					(new Integer((String) regionValueMap.get(RegionMetaData.DISK_STORE_WRITE_BUFFER_SIZE)).intValue()));
			returDiskStore = diskStoreFactory.create((String) regionValueMap.get(RegionMetaData.DISK_STORE_NAME));
		}
	}

	private FunctionResult doSingleRegionOperation(FunctionContext functionContext, SingleRegionOperationInput input) {

		FunctionResult returnResult = new FunctionResult();

		String region = input.getRegion();
		String operation = input.getOperation();
		String key = input.getKey();
		Object value = input.getValue();
		String query = input.getQuery();
		Object[] queryParam = input.getQueryParam();
		Map<String, Object> valueMap = input.getValueMap();
		Map<String, Object> regionAttributes = input.getRegionAttributes();

		if ((region != null) && EnumUtils.isValidEnum(CacheFunctionEnabledDataRegion.class, region.toUpperCase())) {

			LOGGER.info("Executing doSingleRegionOperation with : input = {}", gson.toJson(input));

			switch (CacheSupportedFunctionOperation.valueOf(operation.toUpperCase())) {

			case CONTAINSKEY:
				if ((key != null) && (key instanceof String)) {
					try {
						boolean functionResult = executeContainsKeyOperation(region.toUpperCase(), key);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setBooleanResult(functionResult);
						returnResult.setResultType(FunctionResultType.BOOLEAN.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeContainsKeyOperation : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case CONTAINSVALUE:
				if (value != null) {

					try {

						boolean functionResult = executeContainsValueOperation(region.toUpperCase(), value);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setBooleanResult(functionResult);
						returnResult.setResultType(FunctionResultType.BOOLEAN.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeContainsValueOperation : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}

				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case CONTAINSVALUEFORKEY:
				if ((key != null) && (key instanceof String)) {
					try {
						boolean functionResult = executeContainsValueForTheKey(region.toUpperCase(), key);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setBooleanResult(functionResult);
						returnResult.setResultType(FunctionResultType.BOOLEAN.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeContainsValueOperation : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case CREATE:
				if ((key != null) && (key instanceof String) && (value != null)) {
					try {
						executeCreate(region.toUpperCase(), key, value);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.VOID.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeContainsValueOperation : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());

					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case FIND:
				if ((query != null) && (query instanceof String) && (queryParam != null)
						&& queryParam instanceof Object[]) {
					try {
						SelectResults<Object> resultAsObj = executeFind(region.toUpperCase(), query, queryParam);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setListResult(resultAsObj.asList());
						returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeFind : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}

				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case FINDUNIQUE:

				if ((query != null) && (query instanceof String) && (queryParam != null)
						&& queryParam instanceof Object[]) {
					try {
						Object resultObj = executeFindUnique(region.toUpperCase(), query, queryParam);
						if (resultObj != null) {
							ArrayList<Object> resultAsList = new ArrayList<Object>();
							resultAsList.add(resultObj);
							returnResult.setStatus(Status.SUCCESSFUL.getValue());
							returnResult.setListResult(resultAsList);
							returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
						}
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeFindUnique : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}

				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					;
				}
				break;

			case GET:
				if ((key != null) && (key instanceof String)) {
					try {
						Object resultAsObject = executeGet(region.toUpperCase(), key);
						ArrayList<Object> resultAsList = new ArrayList<Object>();
						resultAsList.add(resultAsObject);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setListResult(resultAsList);
						returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.info("Exception in calling executeGet : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;
				
			case GET_FOR_UPDATE:
				if ((key != null) && (key instanceof String)) {
					try {
						Object resultAsObject = executeGet(region.toUpperCase(), key);
						ArrayList<Object> resultAsList = new ArrayList<Object>();
						resultAsList.add(resultAsObject);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setListResult(resultAsList);
						returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
						returnResult.setTime(DateType.DATE_FORMAT_WITH_NANO_SECONDS.getDateAsString());
						returnResult.setGetForUpdate(true);
					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.info("Exception in calling executeGet : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;
				
			case UPDATE:
				break;				
				
			case GETALL:				
				try {
					LOGGER.info("Executing executeGetAll function method with query : {}", " <trace> "+ query);
					SelectResults<Object> resultAsList = executeGetAll(region);
					returnResult.setStatus(Status.SUCCESSFUL.getValue());
					returnResult.setListResult(resultAsList.asList());
					returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
				} catch (Exception e) {
					// e.printStackTrace();
					LOGGER.info("Exception in Executing getall function method : message : {}",  e.getMessage());
					returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
				}
				 
				break;
			case PUT:
				if ((key != null) && (key instanceof String) && (value != null)) {
					try {
						executePut(region.toUpperCase(), key, value);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.VOID.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executePut : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case PUTALL:
				if ((valueMap != null) && (valueMap instanceof Map)) {

					try {
						executePutAll(region.toUpperCase(), valueMap);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.VOID.getValue());

					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.debug("Exception in calling executePutAll : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					 
				}
				break;

			case PUTIFABSENT:
				if ((key != null) && (key instanceof String) && (value != null))

					try {

						executePutIfAbsent(region.toUpperCase(), key, value);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.VOID.getValue());

					} catch (Exception e) {
						LOGGER.debug("Exception in calling executePutIfAbsent : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());

					}
				else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					;
				}
				break;

			case QUERY:

				if ((query != null) && (query instanceof String))
					try {
						LOGGER.info("Executing query function method with query : {}", " <trace> "+ query);
						SelectResults<Object> resultAsList = executeQuery(region.toUpperCase(), query);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setListResult(resultAsList.asList());
						returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
					} catch (Exception e) {
						// e.printStackTrace();
						LOGGER.info("Exception in Executing query function method : message : {}",  e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());

					}
				else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					;
				}
				break;

			case REMOVE:
				if ((key != null) && (key instanceof String))
					try {
						executeRemove(region.toUpperCase(), key);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.VOID.getValue());
					} catch (Exception e) {
						LOGGER.info("Exception in calling executeRemove : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
				}
				break;

			case REPLACE:

				if ((key != null) && (key instanceof String) && (value != null))
					try {
						executeReplace(region.toUpperCase(), key, value);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.VOID.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling executeReplace : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					;
				}
				break;

			case REPLACEWITHVERIFICATION:
				if ((key != null) && (key instanceof String) && (value != null))
					try {
						Object resultAsObj = executeReplaceWithVerification(region.toUpperCase(), key, value);
						List<Object> returnList = new ArrayList<Object>();
						if (resultAsObj != null) {
							returnList.add(resultAsObj);
						}
						returnResult.setListResult(returnList);
						returnResult.setStatus(Status.SUCCESSFUL.getValue());
						returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
					} catch (Exception e) {

						LOGGER.debug("Exception in calling executeReplaceWithVerification : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					;
				}
				break;

			case CREATEREGION:

				if (regionAttributes != null) {
					try {
						Region<String, Object> createdRegion = createOrRetrieveRegion(regionAttributes);
						List<Object> returnList = new ArrayList<Object>();
						if (createdRegion != null) {
							returnList.add(createdRegion);
						}
						returnResult.setListResult(returnList);
						returnResult.setResultType(FunctionResultType.OBJECTS.getValue());
					} catch (Exception e) {
						LOGGER.debug("Exception in calling createOrRetrieveRegion : " + e.getMessage());
						returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
					}
				} else {
					returnResult.setStatus(Status.INVALID_INPUT.name());
					;
				}
				break;
			case CLEAR:
				try {
					clearRegion(region);
					returnResult.setStatus(Status.SUCCESSFUL.getValue());
					returnResult.setResultType(FunctionResultType.VOID.getValue());
				} catch (Exception e) {
					LOGGER.debug("Exception in calling clearRegion : " + e.getMessage());
					returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
				}
				break;

			default:
				returnResult.setStatus(Status.UNKNOWN_OPERATION.getValue());
				break;
			}
		}
		
		//-  need to add check returnResult.

		return returnResult;
	}

	private SingleRegionOperationInput prepareSingleRegionInput(Map<String, Object> input) {

		SingleRegionOperationInput singleRegionOperationInput = new SingleRegionOperationInput();

		String region = (String) input.get(OperationInputKey.REGION_NAME);
		singleRegionOperationInput.setRegion(region);

		String operation = (String) input.get(OperationInputKey.OPERATION);
		singleRegionOperationInput.setOperation(operation);

		String key = (String) input.get(OperationInputKey.KEY);
		singleRegionOperationInput.setKey(key);

		Object value = (Object) input.get(OperationInputKey.VALUE);
		singleRegionOperationInput.setValue(value);

		String query = (String) input.get(OperationInputKey.QUERY);
		singleRegionOperationInput.setQuery(query);

		Object[] queryParam = (Object[]) input.get(OperationInputKey.QUERY_PARAM);
		singleRegionOperationInput.setQueryParam(queryParam);
		@SuppressWarnings("unchecked")
		Map<String, Object> valueMap = (Map<String, Object>) input.get(OperationInputKey.VALUE_MAP);
		singleRegionOperationInput.setValueMap(valueMap);

		@SuppressWarnings("unchecked")
		Map<String, Object> regionAttributes = (Map<String, Object>) input.get(OperationInputKey.REGION_ATTRIBUTES);
		singleRegionOperationInput.setRegionAttributes(regionAttributes);

		return singleRegionOperationInput;

	}

}
