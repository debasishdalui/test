package com.sample.data.flow.service;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.util.MimeTypeUtils;

import sample.gemfire.model.business.models.Person;

import com.google.gson.Gson;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class StreamService {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(StreamService.class);
	
	private Gson gson = new Gson();

	@Autowired
	private Source channels;

	
	public boolean streamPerson(final Person person) {
		
		MessageHeaderAccessor messageHeaderAccessor = new MessageHeaderAccessor();
		messageHeaderAccessor.setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON);
		final String personAsJson = gson.toJson(person);
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("Data-Flow-Source-Input", person.toString());
		}}.toString());

		Message<String> message = MessageBuilder.createMessage(personAsJson, messageHeaderAccessor.getMessageHeaders());
		
		return channels.output().send(message);
	}
}
