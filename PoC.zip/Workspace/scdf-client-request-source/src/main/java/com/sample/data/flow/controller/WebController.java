package com.sample.data.flow.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import sample.gemfire.model.business.models.Person;

import com.sample.data.flow.service.StreamService;

@Controller
public class WebController extends WebMvcConfigurerAdapter {
	
	@Autowired
	StreamService streamService;
	
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/results").setViewName("results");
    }
    
    @GetMapping("/")
    public String showForm(Person person) {
        return "form";
    }
    
    @PostMapping("/")
    public String checkPersonInfo(@Valid Person person, BindingResult bindingResult, Model model) {

    	
        if (bindingResult.hasErrors()) {
            return "form";
        } else {
        	String key = java.util.UUID.randomUUID().toString();
        	person.setId(key);
        	model.addAttribute("personId", key);
        	streamService.streamPerson(person);
        	return "results";
        }
    }

}
