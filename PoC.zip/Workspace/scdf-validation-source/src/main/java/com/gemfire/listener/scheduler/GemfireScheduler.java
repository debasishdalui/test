package com.gemfire.listener.scheduler;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.gemfire.listener.scheduler.service.SchedulerService;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class GemfireScheduler {
	
	@Autowired
	SchedulerService schedulerService;
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(GemfireScheduler.class);
	
	@Scheduled(fixedDelayString = "${SCHEDULER.FIXED.DELAY_MILLI_SECONDS}")
	public void pickUp() {
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("GEMFIRE-SCHEDULER-CALLED", "TRUE");
		}}.toString());
		
		schedulerService.fetchAndStream("");
	}

}
