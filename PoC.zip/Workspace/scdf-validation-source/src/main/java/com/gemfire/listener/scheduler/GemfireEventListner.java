package com.gemfire.listener.scheduler;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.gemfire.listener.scheduler.service.SchedulerService;
import com.gemstone.gemfire.cache.Operation;
import com.gemstone.gemfire.cache.query.CqEvent;
import com.splunk.logging.SplunkCimLogEvent;

public class GemfireEventListner {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(GemfireEventListner.class);
	
	@Autowired
	SchedulerService schedulerService;
	
	public void handleEvent(CqEvent event) {
		
		Operation queryOperation = event.getQueryOperation();
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("QUERY-OPERATION-IN-GEMFIRE-EVENT-LISTENER", queryOperation);
		}}.toString());
		
		if (queryOperation.isCreate()) {
			schedulerService.fetchAndStream(event.getKey().toString());
		}
	}

}
