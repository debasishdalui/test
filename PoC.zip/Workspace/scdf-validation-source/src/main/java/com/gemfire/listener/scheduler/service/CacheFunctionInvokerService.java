package com.gemfire.listener.scheduler.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import sample.gemfire.model.business.models.Person;
import sample.gemfire.model.business.models.PersonFindResult;
import sample.gemfire.model.business.models.PersonQueryResult;
import sample.gemfire.model.function.CacheFunctionEnabledDataRegion;
import sample.gemfire.model.function.CacheSupportedFunctionOperation;
import sample.gemfire.model.function.FunctionResult;
import sample.gemfire.model.function.FunctionResultType;
import sample.gemfire.model.function.OperationInputKey;
import sample.gemfire.model.function.RegionOperationType;
import sample.gemfire.model.function.Status;

import com.gemstone.gemfire.cache.client.Pool;
import com.gemstone.gemfire.cache.execute.Execution;
import com.gemstone.gemfire.cache.execute.FunctionService;
import com.gemstone.gemfire.cache.execute.ResultCollector;
import com.google.gson.Gson;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class CacheFunctionInvokerService {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(CacheFunctionInvokerService.class);
	
	private Gson gson = new Gson();
	
	private static final String CACHE_FUNCTION_NAME = "CACHE_FUNCTION";
	private static final String QUERY_EXECUTION_ERROR_MSG = "";
	private static final String QUERY_EXECUTION_INPUT_DATA_ERROR_MSG = "";
	private static final String UKNOWN_OPERATION_MSG = "";
	private static final String FIND_EXECUTION_ERROR_MSG = "";
	private static final String FIND_EXECUTION_INPUT_DATA_ERROR_MSG = "";

	
	@Resource(name = "locatorPool")
	private Pool pool;
	
	public PersonQueryResult findPersonWithQuery(String query) {

		PersonQueryResult returnResult = new PersonQueryResult();

		Map<String, Object> functionInput = new HashMap<>();
		functionInput.put(OperationInputKey.OPERATION_TYPE, RegionOperationType.SINGLE_REGION_OPERATION.getValue());

		functionInput.put(OperationInputKey.REGION_NAME,
				CacheFunctionEnabledDataRegion.PERSON_PARTITIONED_REGION.getValue());
		functionInput.put(OperationInputKey.OPERATION, CacheSupportedFunctionOperation.QUERY.getValue());
		functionInput.put(OperationInputKey.QUERY, query);
		Execution functionExecution = FunctionService.onServer(pool).withArgs(functionInput);
		ResultCollector<?, ?> results = functionExecution.execute(CACHE_FUNCTION_NAME);

		// receive the generic function result
		// FunctionResult functionResult = (FunctionResult) results.getResult();
		List<?> list = (List<?>) results.getResult();
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("FIND-PERSON-QUERY-RESULT", list);
		}}.toString());
		FunctionResult functionResult = (FunctionResult) list.get(0);

		// extract the status from genetic result
		String status = functionResult.getStatus();
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("FIND-PERSON-QUERY-STATUS", status);
		}}.toString());
		if (status.equalsIgnoreCase(Status.SUCCESSFUL.getValue()) && functionResult.getResultType().equalsIgnoreCase(FunctionResultType.OBJECTS.getValue())) {
				// the executed function is a type of data check so the return
				// is YES/NO boolean value
				returnResult.setStatus(Status.SUCCESSFUL.getValue());
				LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
					addField("FIND-PERSON-QUERY-RESULT-VALUES-FETCH", "SUCCESSFULL");
				}}.toString());

				List<Object> ObjResults = functionResult.getListResult();
				List<Person> resultAsClientRequest = new ArrayList<>();
				for (Object obj : ObjResults) {
					resultAsClientRequest.add((Person) obj);
				}
				returnResult.setData(resultAsClientRequest);
		}

		if (status.equalsIgnoreCase(Status.UNSUCCESSFUL.getValue())) {
			returnResult.setStatus(Status.UNSUCCESSFUL.getValue());
			returnResult.setMessage(CacheFunctionInvokerService.QUERY_EXECUTION_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("FIND-PERSON-QUERY-RESULT-VALUES-FETCH", "UNSUCCESSFUL");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.INVALID_INPUT.getValue())) {
			returnResult.setStatus(Status.INVALID_INPUT.getValue());
			returnResult.setMessage(CacheFunctionInvokerService.QUERY_EXECUTION_INPUT_DATA_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("FIND-PERSON-QUERY-RESULT-VALUES-FETCH", "INVALID_INPUT");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.UNKNOWN_OPERATION.getValue())) {
			returnResult.setStatus(Status.UNKNOWN_OPERATION.getValue());
			returnResult.setMessage(CacheFunctionInvokerService.UKNOWN_OPERATION_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("FIND-PERSON-QUERY-RESULT-VALUES-FETCH", "UNKNOWN_OPERATION");
			}}.toString());
		}

		return returnResult;

	}
	
	public PersonFindResult findPersonByKey(String key) {
		PersonFindResult returnValue = new PersonFindResult();

		Map<String, Object> functionInput = new HashMap<>();
		functionInput.put(OperationInputKey.OPERATION_TYPE, RegionOperationType.SINGLE_REGION_OPERATION.getValue());
		functionInput.put(OperationInputKey.REGION_NAME, CacheFunctionEnabledDataRegion.PERSON_PARTITIONED_REGION.getValue());
		functionInput.put(OperationInputKey.OPERATION, CacheSupportedFunctionOperation.GET.getValue());
		functionInput.put(OperationInputKey.KEY, key);
		Execution functionExecution = FunctionService.onServer(pool).withArgs(functionInput);
		ResultCollector<?, ?> results = functionExecution.execute(CACHE_FUNCTION_NAME);

		// receive the generic function result
		List<?> list = (List<?>) results.getResult();
		FunctionResult functionResult = (FunctionResult) list.get(0);

		// extract the status from genetic result
		String status = functionResult.getStatus();
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("FIND-PERSON-KEY-STATUS", status);
		}}.toString());
		if (status.equalsIgnoreCase(Status.SUCCESSFUL.getValue())) {
			if (functionResult.getResultType().equalsIgnoreCase(FunctionResultType.OBJECTS.getValue())) {
				returnValue.setStatus(Status.SUCCESSFUL.getValue());
				LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
					addField("FIND-PERSON-KEY-RESULT-VALUES-FETCH", "SUCCESSFULL");
				}}.toString());
				if ((Person) functionResult.getListResult().get(0) != null) {
					returnValue.setData((Person) functionResult.getListResult().get(0));
				} else {
					returnValue.setStatus(Status.NO_RESULT.getValue());
				}
			}
		}

		if (status.equalsIgnoreCase(Status.UNSUCCESSFUL.getValue())) {
			returnValue.setStatus(Status.UNSUCCESSFUL.getValue());
			returnValue.setMessage(CacheFunctionInvokerService.FIND_EXECUTION_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("FIND-PERSON-KEY-RESULT-VALUES-FETCH", "UNSUCCESSFUL");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.INVALID_INPUT.getValue())) {
			returnValue.setMessage(Status.INVALID_INPUT.getValue());
			returnValue.setMessage(CacheFunctionInvokerService.FIND_EXECUTION_INPUT_DATA_ERROR_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("FIND-PERSON-KEY-RESULT-VALUES-FETCH", "INVALID_INPUT");
			}}.toString());
		}

		if (status.equalsIgnoreCase(Status.UNKNOWN_OPERATION.getValue())) {
			returnValue.setStatus(Status.UNKNOWN_OPERATION.getValue());
			returnValue.setMessage(CacheFunctionInvokerService.UKNOWN_OPERATION_MSG);
			LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
				addField("FIND-PERSON-KEY-RESULT-VALUES-FETCH", "UNKNOWN_OPERATION");
			}}.toString());
		}

		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("FIND-PERSON-KEY-RESULT", returnValue.toString());
		}}.toString());

		return returnValue;
	}
}
