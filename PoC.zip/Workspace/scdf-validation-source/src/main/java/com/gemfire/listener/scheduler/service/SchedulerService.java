package com.gemfire.listener.scheduler.service;

import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.util.MimeTypeUtils;

import sample.gemfire.model.business.models.Person;
import sample.gemfire.model.business.models.PersonFindResult;
import sample.gemfire.model.business.models.PersonQueryResult;
import sample.gemfire.model.function.Status;

import com.google.gson.Gson;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class SchedulerService {
	
	@Autowired
	CacheFunctionInvokerService cacheFunctionInvokerService;
	
	@Autowired
	private Source channels;
	
	private final Gson gson = new Gson();
	
	@Value("${SCHEDULER.QUERY}")
	@Getter
	@Setter(AccessLevel.PUBLIC)
	@NotNull
	private String query;
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(SchedulerService.class);
	
	public void fetchAndStream(String key) {
		
		
		if ("".equals(key)) {
			
			PersonQueryResult res = cacheFunctionInvokerService.findPersonWithQuery(query);
			
			if (res.getStatus().equalsIgnoreCase(Status.SUCCESSFUL.getValue())) {
				List<Person> queryResultData = res.getData();
				if (!queryResultData.isEmpty()) {
					for (Person person : queryResultData) {
						Message<String> message = buildChannelOutputMessage(person);
						boolean status = channels.output().send(message);
						LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
							addField("GEMFIRE-SCHEDULER-STREAM-STATUS", status);
						}}.toString());
					}
				}
			}
		} else {
			
			PersonFindResult res = cacheFunctionInvokerService.findPersonByKey(key);
			
			if (res.getStatus().equalsIgnoreCase(Status.SUCCESSFUL.getValue())) {
				Person person = res.getData();
				Message<String> message = buildChannelOutputMessage(person);
				boolean status = channels.output().send(message);
				LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
					addField("GEMFIRE-EVENT-LISTENER-STREAM-STATUS", status);
				}}.toString());
			}
		}
		
	}
	
	private Message<String> buildChannelOutputMessage(Person person) {
		MessageHeaderAccessor messageHeaderAccessor = new MessageHeaderAccessor();
		messageHeaderAccessor.setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON);
		String personAsJson = gson.toJson(person);

		return MessageBuilder.createMessage(personAsJson, messageHeaderAccessor.getMessageHeaders());
	}
}
