package com.sample.data.flow.service;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import sample.gemfire.model.business.models.Person;

import com.google.gson.Gson;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class TransformService {
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(TransformService.class);
	
	private Gson gson = new Gson();

	@Transformer(inputChannel = Processor.INPUT, outputChannel = Processor.OUTPUT)
	public String transform(Message<String> message) {
		String personAsJson = message.getPayload();
		final Person person = gson.fromJson(personAsJson, Person.class);
		person.setStatus("New");
		
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("Data-Flow-Processor-Input", person.toString());
		}}.toString());
		
		return gson.toJson(person);
		
	}
}
