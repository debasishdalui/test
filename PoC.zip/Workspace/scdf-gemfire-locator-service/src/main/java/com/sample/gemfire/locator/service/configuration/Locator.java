package com.sample.gemfire.locator.service.configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.validation.constraints.NotNull;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gemstone.gemfire.distributed.LocatorLauncher;
import com.splunk.logging.SplunkCimLogEvent;

@Component
public class Locator {
		
	@Value("${DATA.CACHE.LOCATOR.NAME}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String name;
	
	@Value("${DATA.CACHE.LOCATOR.PORT}")
	@Getter @Setter (AccessLevel.PUBLIC) 	
	@NotNull
	private String port;
	
	@Getter @Setter (AccessLevel.PUBLIC) 	
	private LocatorLauncher locatorLauncher;
	
	@Value("${SPLUNK.EVENT.NAME}")
	@NotNull
	private String splunkEventName;
	
	@Value("${SPLUNK.EVENT.ID}")
	@NotNull
	private String splunkEventId;
	
	private static Log LOGGER = LogFactory.getLog(Locator.class);
	
	@PostConstruct
	public void init() {

		locatorLauncher = new LocatorLauncher.Builder()
				.setMemberName(getName()).setPort(new Integer(getPort()))
				.build();
		locatorLauncher.start();

		System.out.println("Locator successfully started");
		
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("LOCATOR-START", "SUCCESS");
		}}.toString());

	}
	
	@PreDestroy
	public void shutdown() {

		locatorLauncher.stop();
		LOGGER.info(new SplunkCimLogEvent(splunkEventName, splunkEventId) {{
			addField("LOCATOR-SHUTDOWN", "SUCCESS");
		}}.toString());
	}
	

}
